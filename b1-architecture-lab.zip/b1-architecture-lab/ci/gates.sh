#!/usr/bin/env bash
# Gates executáveis SEM Jenkins: o Jenkinsfile só orquestra estes scripts (mesma lógica local e no CI).
# Uso: ci/gates.sh <componente>   componente = core | ia | iot | all
set -euo pipefail
cd "$(dirname "$0")/.."
E=evidencias
core() {
  echo "### GATE core: fronteiras modulares (catraca)"; python3 -I $E/d1-drivers-evolucao-core/check_module_boundaries.py core/src/main/java $E/d1-drivers-evolucao-core/baseline-vazamentos.txt
  echo "### GATE core: domínio do Ranking sem Spring/JPA (testes em JDK puro)"; $E/d2-organizacao-interna-core/executar-lab.sh
  echo "### GATE core: contrato de degradação da IA / outbox"; (cd $E/d3-servico-python-ia/lab && d=$(mktemp -d) && javac -encoding UTF-8 -d "$d" IaFailureLab.java && java -Dstdout.encoding=UTF-8 -cp "$d" IaFailureLab | tail -2)
  (cd $E/d4-comunicacao-eventos/lab && d=$(mktemp -d) && javac -encoding UTF-8 -d "$d" EventosLab.java && java -Dstdout.encoding=UTF-8 -cp "$d" EventosLab | tail -1)
}
iot() { echo "### GATE iot: lab MQTT (dedup, offline, payload inválido)"; (cd $E/d5-iot-mqtt/lab && python3 lab_mqtt.py | tail -1); echo "### GATE iot: observabilidade"; (cd $E/d6-cicd-observabilidade/lab && python3 lab_observabilidade.py | tail -1); }
ia()  { python3 -m py_compile $E/d3-servico-python-ia/ia-service/app.py && echo "ia-service: sintaxe ok"; }
case "${1:-all}" in core) core;; ia) ia;; iot) iot;; all) core; ia; iot;; *) echo "uso: $0 core|ia|iot|all"; exit 2;; esac
echo "GATES OK ($1)"
