package com.exemplo.usuario.recomendacao.internal;

import com.exemplo.usuario.recomendacao.application.RecomendacaoProvider;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.client.SimpleClientHttpRequestFactory;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestClient;
import java.util.*;

/** Adapter HTTP/REST para o ia-service (FastAPI). Timeouts curtos + circuit breaker mínimo (sem nova dependência).
 *  Se a carga justificar, trocar por Resilience4j sem mudar a porta. */
@Component
public class IaHttpClient implements RecomendacaoProvider {
    private static final int LIMITE_FALHAS = 3;
    private static final long ABERTO_MS = 5_000;
    private final RestClient rest;
    private int falhasSeguidas = 0;
    private long abertoAte = 0;

    public IaHttpClient(@Value("${ia.base-url:http://localhost:8000}") String baseUrl,
                        @Value("${ia.timeout-ms:800}") int timeoutMs) {
        var f = new SimpleClientHttpRequestFactory();
        f.setConnectTimeout(300);
        f.setReadTimeout(timeoutMs);
        this.rest = RestClient.builder().baseUrl(baseUrl).requestFactory(f).build();
    }

    @Override
    @SuppressWarnings("unchecked")
    public List<String> recomendar(Long usuarioId) {
        if (System.currentTimeMillis() < abertoAte) throw new IllegalStateException("circuito aberto");
        try {
            Map<String, Object> body = rest.get().uri("/v1/recomendacoes/{id}", usuarioId).retrieve().body(Map.class);
            sucesso();
            List<Map<String, Object>> itens = (List<Map<String, Object>>) body.get("itens");
            return itens.stream().map(i -> String.valueOf(i.get("titulo"))).toList();
        } catch (RuntimeException e) {
            falha();
            throw e;
        }
    }
    private synchronized void sucesso() { falhasSeguidas = 0; }
    private synchronized void falha() {
        if (++falhasSeguidas >= LIMITE_FALHAS) abertoAte = System.currentTimeMillis() + ABERTO_MS;
    }
}
