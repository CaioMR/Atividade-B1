package com.exemplo.usuario.ranking.internal.persistence;

import com.exemplo.usuario.ranking.application.port.PerfilGamificacaoReader;
import com.exemplo.usuario.ranking.domain.PerfilGamificacao;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;
import java.util.List;

/** Adapter de saída JPA. Reaproveita a query existente (RPC: não reescrever o produto). */
@Component
public class JpaPerfilGamificacaoReader implements PerfilGamificacaoReader {
    private final RankingRepository repository;
    public JpaPerfilGamificacaoReader(RankingRepository repository) { this.repository = repository; }

    @Override @Transactional(readOnly = true)
    public List<PerfilGamificacao> listarTodos() {
        return repository.buscarRanking().stream().map(a -> new PerfilGamificacao(
            a.getUsuario().getId(), a.getUsuario().getNome(),
            a.getCursosConcluidosComSucesso(), a.getMoedas())).toList();
    }
}
