package com.exemplo.usuario.ranking.domain;

/** Regra de pontuação isolada: muda com frequência (ASR de modificabilidade) sem tocar em banco ou framework. */
public interface PontuacaoPolicy {
    long calcular(PerfilGamificacao perfil);
}
