package com.exemplo.usuario.recomendacao.application;

import com.exemplo.usuario.recomendacao.api.RecomendacaoResponseDTO;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
public class RecomendacaoService {
    private static final Logger log = LoggerFactory.getLogger(RecomendacaoService.class);
    private final RecomendacaoProvider provider;
    public RecomendacaoService(RecomendacaoProvider provider) { this.provider = provider; }

    public RecomendacaoResponseDTO recomendar(Long usuarioId) {
        try {
            return new RecomendacaoResponseDTO(usuarioId, "ia-ml", true, provider.recomendar(usuarioId));
        } catch (RuntimeException e) {
            log.warn("IA indisponível, usando fallback: {}", e.toString());
            // Degradação aceita (ADR-003): lista genérica do próprio Core, marcada como não personalizada.
            return new RecomendacaoResponseDTO(usuarioId, "core-fallback", false,
                List.of("Curso mais concluído 1", "Curso mais concluído 2"));
        }
    }
}
