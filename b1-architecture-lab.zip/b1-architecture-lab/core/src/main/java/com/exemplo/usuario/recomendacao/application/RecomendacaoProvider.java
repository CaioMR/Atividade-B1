package com.exemplo.usuario.recomendacao.application;

import java.util.List;

/** Porta de saída para o provedor de IA. Lança exceção se indisponível (o serviço decide o fallback). */
public interface RecomendacaoProvider {
    List<String> recomendar(Long usuarioId);
}
