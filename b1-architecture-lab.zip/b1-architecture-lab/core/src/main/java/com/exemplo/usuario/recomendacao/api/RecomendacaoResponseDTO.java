package com.exemplo.usuario.recomendacao.api;

import java.util.List;

/** personalizado=false indica comportamento degradado (IA indisponível). */
public record RecomendacaoResponseDTO(Long usuarioId, String origem, boolean personalizado, List<String> itens) {}
