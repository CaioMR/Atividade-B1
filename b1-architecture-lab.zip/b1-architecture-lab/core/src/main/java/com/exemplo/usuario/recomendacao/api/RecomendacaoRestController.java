package com.exemplo.usuario.recomendacao.api;

import com.exemplo.usuario.recomendacao.application.RecomendacaoService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/recomendacoes")
@Tag(name = "Recomendação")
public class RecomendacaoRestController {
    private final RecomendacaoService service;
    public RecomendacaoRestController(RecomendacaoService service) { this.service = service; }

    @GetMapping("/{usuarioId}")
    @Operation(summary = "Recomendações da IA; se indisponível, devolve fallback com personalizado=false")
    public RecomendacaoResponseDTO recomendar(@PathVariable Long usuarioId) { return service.recomendar(usuarioId); }
}
