package com.exemplo.usuario.ranking.domain;

/** Visão de leitura do Ranking: só o que a regra de pontuação precisa. Java puro, sem JPA/Spring. */
public record PerfilGamificacao(Long usuarioId, String nome, int cursosConcluidosComSucesso, int moedas) {}
