package com.exemplo.usuario.ranking.domain;

/** Regra vigente na AC1: 100 pontos por curso concluído com sucesso + moedas. */
public class PontuacaoPadrao implements PontuacaoPolicy {
    public static final int PONTOS_POR_CURSO = 100;
    @Override public long calcular(PerfilGamificacao p) {
        return (long) p.cursosConcluidosComSucesso() * PONTOS_POR_CURSO + p.moedas();
    }
}
