package com.exemplo.usuario.ranking.application;

import com.exemplo.usuario.ranking.api.RankingResponseDTO;
import com.exemplo.usuario.ranking.application.port.PerfilGamificacaoReader;
import com.exemplo.usuario.ranking.domain.PontuacaoPadrao;
import org.springframework.stereotype.Service;
import java.util.List;

/** Adapter de entrada: traduz o caso de uso (domínio puro) para o DTO da API. Contrato HTTP inalterado. */
@Service
public class RankingService {
    private final ConsultarRankingUseCase useCase;
    public RankingService(PerfilGamificacaoReader reader) {
        this.useCase = new ConsultarRankingUseCase(reader, new PontuacaoPadrao());
    }
    public List<RankingResponseDTO> listar() {
        return useCase.executar().stream().map(x -> new RankingResponseDTO(
            x.perfil().usuarioId(), x.perfil().nome(),
            x.perfil().cursosConcluidosComSucesso(), x.perfil().moedas(), (int) x.pontos())).toList();
    }
}
