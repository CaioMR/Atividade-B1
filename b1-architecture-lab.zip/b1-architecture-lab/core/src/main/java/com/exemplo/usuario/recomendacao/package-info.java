/** Módulo de negócio: Recomendação inteligente (RF03). Fronteira com o serviço Python de IA (ADR-003). */
package com.exemplo.usuario.recomendacao;
