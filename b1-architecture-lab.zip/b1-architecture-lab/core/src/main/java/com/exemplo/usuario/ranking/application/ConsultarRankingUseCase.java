package com.exemplo.usuario.ranking.application;

import com.exemplo.usuario.ranking.application.port.PerfilGamificacaoReader;
import com.exemplo.usuario.ranking.domain.*;
import java.util.*;
import java.util.stream.IntStream;

/** Caso de uso em Java puro (testável sem Spring). Desempate: nome, depois id, para ordem determinística. */
public class ConsultarRankingUseCase {
    private final PerfilGamificacaoReader reader;
    private final PontuacaoPolicy policy;

    public ConsultarRankingUseCase(PerfilGamificacaoReader reader, PontuacaoPolicy policy) {
        this.reader = reader; this.policy = policy;
    }

    public List<PosicaoRanking> executar() {
        record P(PerfilGamificacao perfil, long pontos) {}
        List<P> ordenados = reader.listarTodos().stream()
            .map(p -> new P(p, policy.calcular(p)))
            .sorted(Comparator.comparingLong(P::pontos).reversed()
                .thenComparing(x -> x.perfil().nome(), Comparator.nullsLast(String::compareToIgnoreCase))
                .thenComparing(x -> x.perfil().usuarioId(), Comparator.nullsLast(Long::compare)))
            .toList();
        return IntStream.range(0, ordenados.size())
            .mapToObj(i -> new PosicaoRanking(i + 1, ordenados.get(i).perfil(), ordenados.get(i).pontos()))
            .toList();
    }
}
