package com.exemplo.usuario.ranking.domain;

public record PosicaoRanking(int posicao, PerfilGamificacao perfil, long pontos) {}
