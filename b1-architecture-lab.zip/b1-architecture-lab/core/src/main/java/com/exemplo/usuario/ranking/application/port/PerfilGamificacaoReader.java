package com.exemplo.usuario.ranking.application.port;

import com.exemplo.usuario.ranking.domain.PerfilGamificacao;
import java.util.List;

/** Porta de saída (Ports & Adapters): o domínio declara do que precisa; a infraestrutura decide como. */
public interface PerfilGamificacaoReader {
    List<PerfilGamificacao> listarTodos();
}
