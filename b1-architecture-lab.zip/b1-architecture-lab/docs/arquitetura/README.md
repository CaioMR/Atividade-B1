# Registro Arquitetural Vivo — Gamificação para Educação Continuada (B1)

> **Equipe:** _(preencher nomes)_ · **Repositório:** _(preencher link)_ · **Papel assumido:** Tech Lead
> Este arquivo é o registro cumulativo (`/docs/arquitetura/README.md`). Cada desafio acrescenta uma seção; a **matriz de ASRs** abaixo evolui a cada um.
> **Leitura de trás para frente:** C4 ← ADR ← ASRs + RPCs ← RF/RNF; a **evidência** (pasta `evidencias/dN-…`) sustenta o raciocínio.

**Catálogo de RFs usado neste registro:** RF01 Ranking · RF02 Conquistas/gamificação · RF03 Recomendação inteligente · RF04 Assistente educacional (RAG/LLM) · RF05 Notificações · RF06 Eventos IoT.

**Como ler a "Evidência":** todo resultado marcado ✅ foi **executado** durante a elaboração e o log está versionado. O que é código-alvo da stack real (Spring Boot, FastAPI, Mosquitto, Jenkins, Prometheus/Grafana) mas **não pôde ser executado** no ambiente de elaboração (sem Maven Central, Docker nem pip) está marcado ⚠️ _não executado_. Ver a tabela de verificação na seção final.

## Matriz cumulativa de ASRs
Um ASR só entra aqui se **alterou estrutura, comunicação, dados, implantação ou operação** (máx. 3 por desafio). Célula = ADR que o tratou.

| ASR | D1 | D2 | D3 | D4 | D5 | D6 |
|---|---|---|---|---|---|---|
| Manutenibilidade / Modificabilidade | ADR-001 | ADR-002 |  |  |  |  |
| Escalabilidade | ADR-001 |  | ADR-003 |  |  |  |
| Complexidade operacional | ADR-001 |  |  |  |  |  |
| Testabilidade |  | ADR-002 |  |  |  |  |
| Tolerância a falhas |  |  | ADR-003 | ADR-004 |  |  |
| Deploy independente |  |  | ADR-003 |  |  | ADR-006 |
| Recuperabilidade |  |  |  | ADR-004 |  | ADR-006 |
| Desacoplamento |  |  |  | ADR-004 |  |  |
| Conectividade intermitente |  |  |  |  | ADR-005 |  |
| Eficiência de comunicação |  |  |  |  | ADR-005 |  |
| Interoperabilidade |  |  |  |  | ADR-005 |  |
| Observabilidade |  |  |  |  |  | ADR-006 |

_Avaliados e **não** promovidos a ASR (e por quê) estão em cada desafio: ex. Desempenho (D1: sem medição), Segurança (D5: tratada por configuração)._

---

# Desafio 1 — Drivers e evolução do Core

**Pergunta do Tech Lead:** há evidência suficiente para distribuir o Core agora, ou uma modularização interna resolve com menor custo?

## 1. RF
RF01 Ranking (carga tende a crescer mais) · RF02 Conquistas/gamificação (evolui continuamente) · evolução de Cursos/Recompensas.

## 2. RNF (FURPS+) e seleção de ASR
| RNF | FURPS+ | ASR? | Como altera estrutura/implantação/operação |
|---|---|---|---|
| Manutenibilidade | Supportability | **SIM** | Capacidades evoluem em ritmos diferentes; sem fronteiras explícitas, cada mudança de Ranking arrisca Cursos/Conquistas (altera **estrutura**). |
| Escalabilidade | Performance | **SIM** | Ranking cresce mais que o resto; pode exigir escala própria no futuro (altera **implantação**). Hoje é só uma **expectativa**, não uma medição. |
| Complexidade operacional | Supportability | **SIM** | 6 devs teriam de absorver rede, contratos, deploys e falhas distribuídas se houver serviços (altera **operação**). |
| Desempenho | Performance | Não agora | Relevante, mas não há latência/throughput medido que prove gargalo arquitetural. |
| Testabilidade | Supportability | Não como driver macro | Melhora com modularização, mas não decide sozinha a decomposição (será ASR no D2). |

## 3. RPC
Core em **Java 17/Spring Boot** · **equipe de 6** · **banco relacional (PostgreSQL)** e **legado AC1** (sem reescrita).

## 4. Alternativas e trade-offs
| Alternativa | Benefícios | Custos/riscos | Avaliação |
|---|---|---|---|
| A — Monólito em Camadas | Menor custo operacional; continuidade | Capacidades espalhadas por `controller/service/repository/domain`; Ranking espalhado em 4 pacotes | Funciona, mas pouco preparada para a evolução |
| **B — Monólito Modular** | Fronteira por capacidade, 1 deploy, 1 banco; facilita futura extração | Mesmo processo/deploy; fronteira **não é imposta** pelo compilador | **Escolhida** |
| C — Decomposição seletiva (serviço de Ranking) | Escala/deploy independentes | Rede, contratos, observabilidade, consistência; custo para 6 devs | Prematura: **sem evidência** de necessidade |

## 5. ADR-001 — Evoluir o Core de Camadas para Monólito Modular
| Campo | Registro |
|---|---|
| **Contexto** | De 1.000 a até 100.000 usuários; Ranking cresce diferente; demais capacidades evoluem. |
| **ASRs / RPCs** | Manutenibilidade, Escalabilidade, Complexidade operacional / Java-Spring, 6 devs, PostgreSQL, legado AC1. |
| **Decisão** | Organizar o Core por **capacidade** (`ranking`, `curso`, `matricula`, `usuario`) num único Spring Boot. Ranking é **candidato explícito** à extração, **não** vira serviço agora. |
| **Consequências (+)** | Coesão por capacidade; mudança localizada; operação compatível com a equipe; extração futura mais barata. |
| **Trade-offs (−)** | Deploy e escala ainda conjuntos. **Achado da evidência:** a modularização por pastas **não reduziu** as dependências entre módulos (ver abaixo) → fronteira precisa ser imposta (gate + D2). |
| **Gatilho de revisão** | p95 de `/api/ranking` > 500 ms por 5 min **ou** necessidade de deploy independente do Ranking (alerta `CoreLatenciaP95Alta`, D6). |

## 6. C4 — Container
```mermaid
flowchart LR
  U[Usuário] --> FE[Front-end web]
  FE -->|REST/JSON| CORE
  subgraph CORE["Core Gamificação · Java/Spring Boot · MONÓLITO MODULAR · 1 deploy"]
    R[ranking]
    C[curso]
    M[matricula]
    US[usuario e assinatura]
  end
  CORE -->|JPA| DB[(PostgreSQL)]
```
O Core continua **um** container; só a organização interna muda (detalhada no C4 Component do D2).

## 7. Evidência ✅ — `evidencias/d1-drivers-evolucao-core/`
`analyze_deps.py` compara o código do zip **Camadas** (antes) com o **Modular** (depois): [`resultado-metricas.json`](../../evidencias/d1-drivers-evolucao-core/resultado-metricas.json).

| Métrica | Antes (camadas) | Depois (modular) | Leitura |
|---|---|---|---|
| Classes / arestas de import internas | 37 / 43 | 37 / 43 | Mesmo código, só reorganizado |
| Pacotes que contêm cada capacidade (ranking · matrícula · curso · usuário) | 4 · 5 · 6 · 7 | 3 · 4 · 4 · 4 | **Coesão melhorou**: tudo de uma capacidade está junto |
| Dependências entre módulos | 7 | **7** | **Acoplamento não mudou** |
| …das quais apontam para pacote `internal` de outro módulo | n/a | **3** | `MatriculaService` usa `UsuarioRepository`, `AssinaturaRepository`, `CursoRepository` direto |

_Limite da medição:_ no baseline a capacidade é inferida pelo **nome** da classe (heurística); análise estática de imports, não de runtime.
**Conclusão:** a modularização atende manutenibilidade (coesão) sem custo distribuído, mas **só pastas não protegem a fronteira**. Ação: `check_module_boundaries.py` ([resultado](../../evidencias/d1-drivers-evolucao-core/resultado-gate-fronteiras.txt)) vira **gate de CI com catraca** (os 3 vazamentos existentes ficam em `baseline-vazamentos.txt` e só podem diminuir; um novo vazamento injetado foi **bloqueado**, exit=1). O que **ainda precisa ser medido** antes de extrair o Ranking: latência/throughput reais de `/api/ranking` com 100 mil usuários (D6).

---

# Desafio 2 — Organização interna do Core

**Pergunta do Tech Lead:** qual dependência realmente precisa ser invertida, e o custo estrutural é proporcional ao problema?

## 1. RF
RF01 Ranking · RF02 Conquistas e regras de gamificação (regras de pontuação mudam com frequência).

## 2. RNF e seleção de ASR
| RNF | ASR? | Como altera estrutura |
|---|---|---|
| Modificabilidade (inclui manutenibilidade/evolução) | **SIM** | A regra de pontuação muda sempre; ela precisa existir **sem** importar JPA/Spring, senão cada mudança toca persistência (altera **estrutura de dependências**). |
| Testabilidade | **SIM** | Se a regra só roda com banco e contexto Spring, testes ficam lentos e raros; domínio puro permite teste unitário e troca de adapter (altera **estrutura** e **pipeline**). |
| Facilidade de evolução / manutenibilidade | Absorvida | Decorre dos dois acima; não é independente (evita ASR "guarda-chuva"). |

## 3. RPC
Core **continua Spring Boot** · regras existentes **reaproveitadas** (`pontos = 100·cursos + moedas`; query `buscarRanking` mantida) · **proibido reescrever** o produto para aplicar padrão.

## 4. Alternativas e trade-offs
| Alternativa | Benefícios | Custos | Avaliação |
|---|---|---|---|
| A — Arquitetura atual (service ↔ JPA direto) | Zero custo | Regra de pontuação acoplada a `Assinatura`/JPA; só testável com contexto | Mantida nos módulos estáveis |
| **B — Ports & Adapters localizado no Ranking** | Regra em Java puro; adapters trocáveis; migração incremental | +6 classes; ordenação passa para memória (ver trade-off) | **Escolhida** |
| C — Hexagonal/Clean completo em todos os módulos | Uniformidade | Custo desproporcional; viola RPC de não reescrever | Rejeitada |

**DDD, Hexagonal, Clean e Onion não são concorrentes:** Hexagonal define *onde ficam as fronteiras* (portas/adaptadores); Onion/Clean impõem a *regra de dependência* (para dentro); DDD diz *como modelar o domínio*. Usamos: fronteira hexagonal + regra de dependência para dentro + DDD **tático mínimo** (`PerfilGamificacao`, `PontuacaoPolicy` como estratégia). Não usamos agregados/eventos de domínio: não há invariante que os justifique ainda.
**A dependência invertida é uma só:** `application → PerfilGamificacaoReader` (porta) ← `JpaPerfilGamificacaoReader` (adapter); antes, o serviço dependia diretamente do repositório JPA.

## 5. ADR-002 — Ports & Adapters no módulo Ranking
| Campo | Registro |
|---|---|
| **Contexto** | Regras de ranking/moedas/badges mudam com frequência; ADR-001 mostrou que fronteiras por pasta não bastam. |
| **ASRs / RPCs** | Modificabilidade, Testabilidade / Spring Boot, reuso de regras, sem reescrita. |
| **Decisão** | No módulo `ranking`: `domain/` (Java puro: `PerfilGamificacao`, `PontuacaoPolicy`, `PontuacaoPadrao`), `application/` (`ConsultarRankingUseCase` + porta `PerfilGamificacaoReader`), `internal/persistence/JpaPerfilGamificacaoReader` (adapter). `RankingService` fica como adapter de entrada; **contrato HTTP inalterado**. |
| **Consequências (+)** | Regra testável sem Spring/banco; trocar a regra não toca o adapter; modelo replicável nos próximos módulos que mudarem. |
| **Trade-offs (−)** | Mais classes; **ordenação em memória** em vez de `ORDER BY` — medido: 100.000 perfis ordenam em ~51 ms (só a CPU do domínio, sem I/O). Se o p95 real exigir, a porta ganha `listarTop(n)` sem mudar o domínio. O adapter JPA ainda lê a entidade `Assinatura` do módulo `usuario` (vazamento herdado, **no baseline** do gate): próximo passo é `usuario` publicar uma view/facade em `usuario.api`. |

## 6. C4 — Component (Core · módulo Ranking)
```mermaid
flowchart TB
  subgraph ranking["Core — módulo ranking"]
    CTRL["RankingRestController<br/>adapter de entrada"] --> SVC[RankingService]
    SVC --> UC[ConsultarRankingUseCase]
    UC --> POL["PontuacaoPolicy / PontuacaoPadrao<br/>regra de domínio"]
    UC --> PORT{{"PerfilGamificacaoReader<br/>porta de saída"}}
    JPA["JpaPerfilGamificacaoReader<br/>adapter JPA"] -.implementa.-> PORT
    TEST["InMemory / CSV<br/>adapters de teste"] -.implementa.-> PORT
  end
  JPA --> REPO[RankingRepository] --> DB[(PostgreSQL)]
```
Regra de dependência: `domain` não importa nada de `application`, `internal`, Spring ou JPA (verificável no import dos arquivos).

## 7. Evidência ✅ — `evidencias/d2-organizacao-interna-core/` (`./executar-lab.sh`, só JDK)
Compila **os mesmos arquivos de `core/…/ranking/{domain,application}`** e roda a mesma suíte sobre **dois adapters** (fake em memória e CSV): [`resultado-lab.txt`](../../evidencias/d2-organizacao-interna-core/resultado-lab.txt) → **7 PASS, 0 FAIL**: ordenação, desempate, ranking vazio, equivalência fake×CSV, e **troca de regra** (100→150 pts/curso) sem tocar adapter. Medição: mediana 51 ms para 100 k perfis.
⚠️ _Não executado:_ `JpaPerfilGamificacaoReader`, `RankingService` refatorado e o restante do Core compilados com Spring/JPA (sem Maven Central); revisados à mão, contrato do DTO preservado. O gate de CI (`mvn verify`) é a confirmação pendente.

---

# Desafio 3 — Serviço Python e IA

**Pergunta do Tech Lead:** Python, por si só, justifica um serviço? ML e RAG precisam da mesma fronteira? Que degradação é aceitável?

## 1. RF
RF03 Recomendação inteligente · RF04 Assistente educacional (RAG/LLM).

## 2. RNF e seleção de ASR
| RNF | ASR? | Como altera arquitetura |
|---|---|---|
| Tolerância a falhas | **SIM** | IA pode cair sem bloquear o fluxo essencial → exige **processo separado**, timeout, circuit breaker e fallback (altera **comunicação e operação**). |
| Deploy independente | **SIM** | Modelos/índices têm ciclo de atualização próprio, diferente do Core → **artefato e pipeline separados** (altera **implantação**). |
| Escalabilidade (carga variável) | **SIM** | RAG/LLM tem carga em rajadas e custo diferente do Core; precisa escalar sem escalar o Core (altera **implantação**). |
| Interoperabilidade | Não | Resolvida por contrato REST/JSON (OpenAPI do FastAPI); não muda a estrutura além disso. |
| Desempenho, Manutenibilidade | Não | Tratados dentro do serviço; não decidem a fronteira. |

## 3. RPC
Core **permanece Java/Spring Boot** · ML/RAG **em Python** · indisponibilidade da IA **não pode bloquear** o fluxo essencial.

## 4. Alternativas e trade-offs
| Alternativa | Benefícios | Custos | Avaliação |
|---|---|---|---|
| A — IA embutida no Core | Sem rede | JVM não executa o ecossistema Python; a RPC o impede; acopla o ciclo do modelo ao do Core | Inviável |
| B — Módulo acoplado (Core chama processo/biblioteca Python) | Menos infra | Mesmo deploy e mesma falha; sem escala própria | Rejeitada: não atende Deploy independente nem Tolerância a falhas |
| **C — Serviço Python independente (REST/JSON)** | Falha isolada; deploy e escala próprios; liberdade de stack | Rede, latência, contrato, observabilidade | **Escolhida** |

**Python por si só não justifica serviço** — o que justifica é a RPC de linguagem **somada** aos ASRs de falha isolada, ciclo próprio e carga variável.
**ML e RAG: uma fronteira, dois módulos isolados.** Têm perfis diferentes (ML: leve/cacheável/ms; RAG: lento/caro/rajadas), o que sugere dois serviços; mas com 6 devs e sem métricas, **um** deployable com dois routers independentes (`/v1/recomendacoes`, `/v1/assistente`) evita custo operacional dobrado. **Gatilho de separação:** p95 do RAG > 3 s, necessidade de GPU/escala só do RAG, ou ciclos de release divergentes.
**Comportamento degradado aceito:** recomendação → lista genérica do Core marcada `personalizado=false`; assistente → mensagem "indisponível" (não é essencial). Matrícula, conclusão e ranking **nunca** dependem da IA.

## 5. ADR-003 — Serviço Python independente para IA
| Campo | Registro |
|---|---|
| **Contexto** | Recomendação e assistente em Python, ciclo e carga próprios, IA pode ficar indisponível. |
| **ASRs / RPCs** | Tolerância a falhas, Deploy independente, Escalabilidade / Core Java, IA Python, essencial não bloqueia. |
| **Decisão** | `ia-service` (FastAPI) como container separado; o Core o consome por **REST/JSON síncrono** atrás da porta `RecomendacaoProvider`, com **timeout 800 ms (conexão 300 ms)**, **circuit breaker** (3 falhas → aberto 5 s) e **fallback**. ML e RAG dividem a fronteira, em routers isolados. |
| **Consequências (+)** | Falha da IA não derruba o Core; IA implanta/escala sozinha; Core desconhece o modelo. |
| **Trade-offs (−)** | +1 container, +latência de rede, contrato a versionar (`/v1`); breaker artesanal (trocável por Resilience4j sem mudar a porta). Sem chamadas assíncronas/streaming para o RAG ainda. |

## 6. C4 — Container
```mermaid
flowchart LR
  U[Usuário] --> FE[Front-end web] -->|REST| CORE
  subgraph CORE["Core Gamificação · Spring Boot · monólito modular"]
    MOD["módulos de negócio<br/>ranking · curso · matricula · usuario"]
    RECO["módulo recomendacao<br/>porta RecomendacaoProvider<br/>timeout + circuit breaker + fallback"]
  end
  CORE -->|JPA| DB[(PostgreSQL)]
  RECO -->|"REST/JSON síncrono · timeout 800 ms"| IA
  subgraph IA["ia-service · Python / FastAPI · deploy próprio"]
    ML["/v1/recomendacoes — ML"]
    RAG["/v1/assistente — RAG/LLM"]
  end
  IA -.futuro.-> VEC[(índice vetorial / LLM)]
```

## 7. Evidência ✅ — `evidencias/d3-servico-python-ia/`
`lab/IaFailureLab.java` sobe o serviço (stub Python com **o mesmo contrato** do `app.py`), consome com a política do ADR e **mata o processo**: [`resultado-lab.txt`](../../evidencias/d3-servico-python-ia/resultado-lab.txt).
Fase 1 (IA no ar): recomendação `origem=ia-ml`, RAG responde. Fase 2 (processo morto): **6/6 chamadas com fallback**, fluxo essencial OK nas 6; 3 primeiras falham por `ConnectException` (2–4 ms) e a partir da 4ª o **circuito abre** (0 ms, sem rede). Fase 3: serviço volta e, passado o tempo de espera, volta a responder `ia-ml`.
**Limites declarados:** (1) falha simulada = processo **morto** (conexão recusada, rápida); um serviço **travado** (o caso caro) só é coberto pelo timeout e **não foi simulado**; (2) "concluir curso" no lab é um stand-in — o isolamento real exige o teste no Core; (3) ⚠️ _não executados:_ `ia-service/app.py` (FastAPI) e `IaHttpClient`/`RecomendacaoService` (Spring) — sem fastapi/Maven; sintaxe do `app.py` verificada.

---

# Desafio 4 — Comunicação e eventos

**Pergunta do Tech Lead:** qual resposta precisa ser imediata, qual pode ser eventual, e que ASR justifica mensageria?

## 1. RF
RF02 Conquistas · RF05 Notificações · eventos da conclusão de atividade (analytics).

## 2. RNF e seleção de ASR
| RNF | ASR? | Como altera arquitetura |
|---|---|---|
| Tolerância a falhas | **SIM** | Falha de notificação não pode impedir a conclusão → o efeito colateral sai da transação principal (altera **comunicação**). |
| Recuperabilidade | **SIM** | Se o consumidor ficar fora por minutos/horas, nada pode ser perdido nem duplicado → mensagem **durável** + retry + DLQ + consumidor idempotente (altera **dados e operação**). |
| Desacoplamento | **SIM** | O Core não deve conhecer cada consumidor (notificação, analytics, futuros) → publicar fato, não chamar destinatário (altera **comunicação**). |
| Consistência | Não (aceita eventual) | **Imediata** só entre matrícula e recompensa (mesma transação ACID); a notificação é eventualmente consistente. |
| Latência / Disponibilidade | Não | Resultado das decisões acima; medidos como evidência. |

## 3. RPC
Operações essenciais concluem **mesmo com consumidor externo fora** · broker **tem custo operacional** (6 devs).

## 4. Alternativas e trade-offs
| Alternativa | Atende os ASRs? | Custos | Avaliação |
|---|---|---|---|
| A — REST síncrono Core → Notificação | Não: conclusão falha ou espera o consumidor | Nenhuma infra | Rejeitada (medido abaixo) |
| B — Evento em processo (`ApplicationEvent`) sem broker | Parcial: desacopla, mas **perde** eventos se o processo cair; consumidor tem de estar no mesmo processo | Zero infra | Boa para consumidor interno; **insuficiente** para consumidor externo |
| **C — Transactional Outbox + RabbitMQ** | **Sim** | +1 broker; tabela `outbox`; consumidores idempotentes | **Escolhida** |
| D — Outbox + Kafka | Sim, **e** replay/ordem/vazão altíssima | Operação bem mais pesada | Rejeitada: o case **não tem** requisito de replay, ordenação por partição nem vazão que a justifique |

**RabbitMQ × Kafka pelo problema do case:** o fluxo é _"notificar um ou poucos consumidores, com retry e DLQ"_ — fila durável com ack e roteamento é o modelo natural e leve. Kafka resolveria reprocessamento histórico e streaming em escala, que **ninguém pediu**. Reavaliar se analytics passar a exigir replay.
**Imediato (síncrono):** registrar conclusão + creditar moedas/badges (mesma transação). **Eventual:** notificação e analytics.

## 5. ADR-004 — Eventos de conclusão via Outbox + RabbitMQ
| Campo | Registro |
|---|---|
| **Contexto** | Concluir curso registra, premia e pode notificar/alimentar analytics; consumidor externo pode estar fora. |
| **ASRs / RPCs** | Tolerância a falhas, Recuperabilidade, Desacoplamento / essencial conclui sempre; broker custa operação. |
| **Decisão** | Na **mesma transação** do Core: matrícula `CONCLUIDA` + recompensa + linha em `outbox` (`CURSO_CONCLUIDO`, `eventId` UUID). Um _relay_ publica no **RabbitMQ** (**at-least-once**, marca `enviado` após o publish). Consumidores são **idempotentes por `eventId`**; falhas repetidas (3) vão à **DLQ**. |
| **Consequências (+)** | Conclusão independe de qualquer consumidor; nada se perde na queda; novos consumidores sem alterar o Core. |
| **Trade-offs (−)** | +RabbitMQ para operar; consistência **eventual** (notificação atrasa); duplicidade possível → idempotência obrigatória; tabela `outbox` a limpar. |

DDL de referência: `CREATE TABLE outbox(id uuid PRIMARY KEY, tipo text NOT NULL, payload jsonb NOT NULL, criado_em timestamptz DEFAULT now(), enviado_em timestamptz);` · consumidores: `UNIQUE(event_id)` na tabela de processados.

## 6. C4 — Container + sequência do fluxo crítico
```mermaid
flowchart LR
  FE[Front-end] -->|REST| CORE
  subgraph CORE["Core · Spring Boot"]
    CON["concluir matrícula<br/>matrícula + recompensa + outbox<br/>1 transação"]
    REL[relay do outbox]
  end
  CON --> DB[(PostgreSQL<br/>tabelas + outbox)]
  REL --> DB
  REL -->|AMQP publish| MQ[(RabbitMQ<br/>fila durável + DLQ)]
  MQ -->|consome com ack| NOT["Notificação<br/>idempotente"]
  MQ -->|consome com ack| ANA["Analytics<br/>idempotente"]
```
```mermaid
sequenceDiagram
  participant U as Usuário
  participant C as Core
  participant DB as PostgreSQL
  participant R as Relay
  participant Q as RabbitMQ
  participant N as Notificação
  U->>C: PUT conclui matrícula
  C->>DB: tx: matrícula + moedas + outbox (COMMIT)
  C-->>U: 200 OK imediato
  loop assíncrono
    R->>DB: lê outbox pendente
    R->>Q: publish (at-least-once)
    Q->>N: entrega (retry, DLQ após 3)
    N-->>Q: ack (idempotente por eventId)
  end
```

## 7. Evidência ✅ — `evidencias/d4-comunicacao-eventos/lab/EventosLab.java` ([`resultado-lab.txt`](../../evidencias/d4-comunicacao-eventos/resultado-lab.txt))
| Cenário | Síncrono (REST) | Assíncrono (outbox) |
|---|---|---|
| Consumidor lento (300 ms), 10 conclusões | latência média **302 ms** | **3 ms** |
| Consumidor **indisponível**, 5 conclusões | **5/5 falham**; 0 matrículas e 0 moedas persistidas (rollback) | **0/5 falham**; 5 matrículas, 500 moedas, 5 eventos pendentes |
| Consumidor volta (com 1 duplicata + 1 mensagem-veneno) | — | **5/5 notificações entregues, sem duplicar**; veneno isolado na **DLQ** após 3 tentativas |

**Limite declarado:** banco e broker são **simulados em memória** (snapshot/rollback; fila durável); o que se prova é a **lógica** da decisão (atomicidade do outbox, at-least-once, idempotência, DLQ), **não** a configuração do RabbitMQ. ⚠️ _Não executados:_ relay/outbox em Spring e RabbitMQ real — passos da PoC da AF. A latência de 3 ms inclui aquecimento de JVM; o ponto é a ordem de grandeza.

---

# Desafio 5 — IoT e MQTT

**Pergunta do Tech Lead:** REST é suficiente? O que o MQTT resolve especificamente? Existe motivo para outro broker depois dele?

## 1. RF
RF06 Receber eventos IoT (presença, início, conclusão) e encaminhá-los ao ecossistema.

## 2. RNF e seleção de ASR
| RNF | ASR? | Como altera arquitetura |
|---|---|---|
| Tolerância à conectividade intermitente | **SIM** | Dispositivo perde rede o tempo todo: precisa de entrega confirmada, buffer local e reconexão barata (altera **protocolo e dados**). |
| Eficiência de comunicação | **SIM** | Baixo poder computacional: sem handshake/cabeçalho por evento, conexão persistente (altera **protocolo**). |
| Interoperabilidade | **SIM** | Dispositivos heterogêneos publicando num contrato de tópico/payload único; o Core não conhece cada dispositivo (altera **comunicação** — gateway/anticorrupção). |
| Segurança de integração | Transversal | Tratada por TLS + credencial por dispositivo + ACL de tópico (config); não muda a estrutura além do broker. |
| Escalabilidade, Disponibilidade | Não agora | Sem volume medido de dispositivos; Mosquitto atende o porte do case. |

## 3. RPC
Dispositivos de **baixo poder computacional** · conectividade **intermitente** · protocolo e broker **adicionam componentes operacionais**.

## 4. Alternativas e trade-offs
| Alternativa | Benefícios | Custos | Avaliação |
|---|---|---|---|
| A — REST direto do dispositivo ao Core | Sem broker novo | Dispositivo precisa falhar/tentar sozinho, sem entrega confirmada padronizada; cabeçalhos e conexão por requisição; **acopla o Core a cada dispositivo** | Rejeitada |
| **B — MQTT (Mosquitto) + gateway consumidor → Core** | QoS 1 + sessão persistente + conexão leve; tópicos por laboratório; Core isolado | +1 broker e +1 gateway | **Escolhida** |
| C — MQTT + ponte para mensageria interna (RabbitMQ) | Múltiplos consumidores internos do evento bruto | **3º** componente de mensageria; mais operação | **Só com gatilho** |

**O que o MQTT resolve:** entrega QoS 1 com confirmação, sessão persistente (broker guarda para o assinante offline), conexão TCP única e pacote mínimo (136 B medido), publicação/assinatura por tópico com ACL por dispositivo.
**Outro broker depois do MQTT?** **Não** agora: o gateway entrega ao Core por HTTP idempotente e o Core já emite seus eventos pelo outbox/RabbitMQ (ADR-004). **Gatilho para a alternativa C:** vários consumidores internos precisarem do evento IoT **bruto**, ou o Core ficar fora por mais tempo do que o Mosquitto consegue reter.
**Duplicidade/perda:** QoS 1 é _at-least-once_ → duplicatas são esperadas; **`eventId` UUID gerado no dispositivo**, deduplicado no gateway e (produção) com `UNIQUE(eventId)` no Core. **Perda:** dispositivo bufferiza offline e reenvia; gateway só confirma (ack manual) **depois** do Core aceitar.

## 5. ADR-005 — MQTT + gateway para eventos IoT
| Campo | Registro |
|---|---|
| **Contexto** | Laboratórios emitem eventos por dispositivos fracos e instáveis; Core não pode virar cliente de cada um. |
| **ASRs / RPCs** | Conectividade intermitente, Eficiência de comunicação, Interoperabilidade / baixo poder, rede instável, broker custa operação. |
| **Decisão** | Mosquitto; tópicos `labs/{lab}/eventos/{tipo}`; payload JSON compacto com `id` (UUID) do dispositivo; **QoS 1**; credencial por dispositivo + ACL; **iot-gateway** assina `labs/+/eventos/#` (sessão persistente), valida, deduplica, traduz para o vocabulário do Core e faz `POST /api/iot/eventos` idempotente. **Sem segundo broker.** |
| **Consequências (+)** | Core independente dos dispositivos; entrega confirmada; baixo custo por evento. |
| **Trade-offs (−)** | +Mosquitto e +gateway; at-least-once exige idempotência; _retained/LWT_ não usados ainda (presença "online/offline" fica para a PoC). |

## 6. C4 — Container
```mermaid
flowchart LR
  DEV["Dispositivos IoT<br/>presença · início · conclusão"] -->|"MQTT QoS 1 · TLS · ACL por dispositivo"| MQTT[(Mosquitto)]
  MQTT -->|"assina labs/+/eventos/#<br/>sessão persistente"| GW["iot-gateway · Python<br/>valida · deduplica · traduz"]
  GW -->|"HTTP POST idempotente<br/>/api/iot/eventos"| CORE["Core Gamificação<br/>Spring Boot"]
  CORE --> DB[(PostgreSQL)]
  CORE -.outbox.-> MQ[(RabbitMQ · ADR-004)]
```
Fluxo do evento: `dispositivo → PUBLISH(QoS1, id) → PUBACK`; `Mosquitto → gateway`; `gateway: valida → deduplica → traduz → POST → ack`; `Core: UNIQUE(eventId) → regras de gamificação → outbox`.

## 7. Evidência ✅ — `evidencias/d5-iot-mqtt/lab/` (`python3 lab_mqtt.py`, [`resultado-lab.txt`](../../evidencias/d5-iot-mqtt/resultado-lab.txt))
Simulador → **broker MQTT 3.1.1 (protocolo real sobre TCP)** → gateway → Core (stub HTTP): **todos PASS**.
1) Fluxo feliz: 3 eventos chegam traduzidos (`pre/ini/fim` → `PRESENCA_REGISTRADA/ATIVIDADE_INICIADA/ATIVIDADE_CONCLUIDA`). 2) **PUBACK perdido** → reenvio com o mesmo `eventId` → Core recebe **+1**, gateway suprime **1 duplicata**. 3) **Dispositivo offline** emite 3 eventos (bufferizados), reconecta → **3/3 chegam**, 0 antes da reconexão. 4) **Payload inválido** (JSON quebrado e tipo desconhecido) → 2 descartados e registrados; o gateway segue processando. 5) PUBLISH QoS 1 = **136 bytes** medidos (payload 107 B).
**Limites:** o broker do lab é um **mini-broker de laboratório** (sem retain/LWT/sessão persistente; a perda de PUBACK é simulada no cliente); TLS/ACL/Mosquitto real e o gateway com `paho-mqtt` (`stack/`) ⚠️ _não executados_. A comparação de bytes com REST **não foi medida** (só o lado MQTT).

---

# Desafio 6 — CI/CD e observabilidade

**Pergunta do Tech Lead:** a arquitetura pode ser construída, implantada e observada com segurança? O que bloqueia deploy? Como distinguir métrica técnica de evidência arquitetural?

## 1. RF
Todos os RFs impactados pelos componentes construídos (RF01–RF06) + operação e evolução da solução.

## 2. RNF e seleção de ASR
| RNF | ASR? | Como altera arquitetura |
|---|---|---|
| Observabilidade | **SIM** | Sem métricas, nenhum ASR anterior é verificável e os gatilhos de revisão (ADR-001/003/004) não disparam (altera **operação**: endpoints `/metrics`, Prometheus, alertas). |
| Deploy independente | **SIM** | Core, IA e gateway têm ciclos diferentes → artefatos e **pipelines por componente** (altera **implantação**). |
| Recuperabilidade / Confiabilidade | **SIM** | A recuperação (backlog, fallback, retry) só é crível se for **exercitada e medida** — vira gate/alerta (altera **operação**). |
| Testabilidade, Desempenho | Não | Entram como _gates_ e métricas, mas não decidem a estrutura. |

## 3. RPC
**Jenkins** é a base da esteira · **Prometheus/Grafana** são as ferramentas do laboratório · artefatos e configurações **versionados**.

## 4. Alternativas e trade-offs
| Alternativa | Benefícios | Custos | Avaliação |
|---|---|---|---|
| A — Pipeline único (monorepo, tudo a cada commit) | Simples de configurar | Mudar a IA rebuilda e reimplanta o Core: **anula** o deploy independente do ADR-003 | Rejeitada |
| **B — Pipeline por componente** (`Jenkinsfile`, `ci/Jenkinsfile.ia`, `ci/Jenkinsfile.iot-gateway`) com `changeset` e **gates em script único** (`ci/gates.sh`) | Cada serviço implanta no seu ritmo; gates executáveis fora do Jenkins | 3 jobs a manter | **Escolhida** |

**O que bloqueia deploy:** (Core) vazamento de fronteira **novo**, teste de domínio quebrado, `mvn verify` falho, serviço sem `/actuator/prometheus` no smoke; (IA) falha de contrato/sintaxe/smoke; (Gateway) lab de dedup/offline ou de observabilidade falhando.
**Métrica técnica × evidência arquitetural:** CPU ou "requests/s" são métricas técnicas. Só vira **evidência** a métrica que (i) está ligada a **um ASR**, (ii) tem **limiar** e (iii) dispara **uma ação/decisão** registrada num ADR:

| ASR (ADR) | Métrica | Limiar → decisão |
|---|---|---|
| Escalabilidade do Ranking (ADR-001) | p95 `http_server_requests{uri="/api/ranking"}` | > 500 ms por 5 min → reavaliar extração do Ranking |
| Tolerância a falhas da IA (ADR-003) | `ia_fallback_total` (taxa) | > 0 por 1 min → alerta "IA em fallback"; sustentado → capacidade/incidente da IA |
| Recuperabilidade (ADR-004/005) | `iot_backlog_retry` (e `outbox` pendente) | > 0 por 2 s → alerta; deve **voltar a 0** após a recuperação |
| Disponibilidade do Core | taxa de 5xx | acima de SLO → incidente |

## 5. ADR-006 — Pipelines por componente e observabilidade ligada aos ASRs
| Campo | Registro |
|---|---|
| **Contexto** | Após D1–D5 há Core Java, serviço Python, gateway, brokers. |
| **ASRs / RPCs** | Observabilidade, Deploy independente, Recuperabilidade / Jenkins, Prometheus/Grafana, tudo versionado. |
| **Decisão** | 3 pipelines Jenkins com `when{changeset}`; gates em `ci/gates.sh`; Core expõe Micrometer em `/actuator/prometheus` (actuator + `micrometer-registry-prometheus` no `pom.xml`); `observabilidade/` versiona `prometheus.yml`, `alerts.yml` e o dashboard Grafana; cada alerta referencia o ADR cujo gatilho monitora. |
| **Consequências (+)** | Mudança em um componente não reimplanta os outros; ASRs viram números e alertas; gatilhos de revisão são objetivos. |
| **Trade-offs (−)** | +3 jobs e +2 serviços de infra (Prometheus/Grafana); métricas custam cardinalidade/manutenção; IA e gateway ainda precisam expor `/metrics` reais (próximo passo da PoC). |

## 6. C4 — Deployment (ambiente de laboratório, Docker Compose)
```mermaid
flowchart TB
  subgraph JEN["Jenkins · 3 pipelines por componente"]
    P1[Jenkinsfile · Core]
    P2[Jenkinsfile.ia]
    P3[Jenkinsfile.iot-gateway]
  end
  subgraph HOST["Host Docker Compose"]
    CORE["Core · Spring Boot<br/>/actuator/prometheus"]
    IA["ia-service · FastAPI"]
    GW["iot-gateway · Python"]
    PG[(PostgreSQL)]
    RMQ[(RabbitMQ)]
    MQ[(Mosquitto)]
    PROM[Prometheus · alerts.yml]
    GRAF[Grafana · dashboard ASRs]
  end
  P1 -->|build · gates · deploy| CORE
  P2 -->|build · gates · deploy| IA
  P3 -->|build · gates · deploy| GW
  CORE --> PG
  CORE --> IA
  CORE -.outbox.-> RMQ
  MQ --> GW --> CORE
  PROM -->|scrape| CORE
  PROM -->|scrape| IA
  PROM -->|scrape| GW
  GRAF --> PROM
```

## 7. Evidência
✅ **Condição provocada e observada** — `evidencias/d6-cicd-observabilidade/lab/lab_observabilidade.py`: o gateway IoT (D5) é instrumentado com 6 métricas (5 contadores/gauge + 1 histograma) no formato Prometheus (`/metrics`), um _scraper_ lê a cada 0,5 s (papel do Prometheus) e o **Core fica indisponível por ~4 s** (503). Resultado ([`resultado-lab.txt`](../../evidencias/d6-cicd-observabilidade/resultado-lab.txt), [`samples.csv`](../../evidencias/d6-cicd-observabilidade/samples.csv), [`metrics-final.txt`](../../evidencias/d6-cicd-observabilidade/metrics-final.txt)): `iot_backlog_retry` **sobe a 40**, 53 falhas de encaminhamento, e **volta a 0** após a recuperação; **119 emitidos = 119 entregues, 0 perdidos, 0 duplicados**; o alerta `IotBacklogCrescendo` **dispararia** (backlog > 0 por ≥ 2 s). Gráfico: [`grafico-evidencia.png`](../../evidencias/d6-cicd-observabilidade/grafico-evidencia.png).
✅ **Gates executados** — `ci/gates.sh all` → **GATES OK** ([`resultado-gates.txt`](../../evidencias/d6-cicd-observabilidade/resultado-gates.txt)): fronteiras, domínio (D2), IA (D3), outbox (D4), MQTT (D5), observabilidade (D6).
**Limites declarados:** o gráfico é um **substituto** do painel Grafana (matplotlib sobre o `samples.csv`) e a avaliação do alerta é **offline**, sem Prometheus. O lab usa fila de retry **em memória** (um crash do gateway perderia o backlog); o `gateway_paho.py` de produção usa **ack manual + sessão persistente** para cobrir isso — ⚠️ _não executado_. ⚠️ _Não executados:_ Jenkinsfiles, `docker-compose.observability.yml`, `prometheus.yml`, `alerts.yml` (validados só quanto à sintaxe YAML/JSON), dashboard Grafana, e `mvn verify`/actuator no Core.

---

# Síntese final do B1

## Decisões levadas para a PoC da Avaliação Final (AF)
| # | Decisão | Entra na PoC? | Como |
|---|---|---|---|
| ADR-001 | Monólito Modular + gate de fronteira com catraca | **Sim** | Mantido; zerar os 3 vazamentos do baseline |
| ADR-002 | Ports & Adapters **só onde a regra muda** (Ranking) | **Sim** | Replicar em `matricula`/conquistas quando a regra mudar; `usuario` publica view para eliminar o vazamento restante do Ranking |
| ADR-003 | `ia-service` FastAPI + fallback | **Sim** | Subir o serviço real, medir p95 e testar **serviço travado** (não só morto) |
| ADR-004 | Outbox + RabbitMQ | **Sim (mínimo)** | Outbox + 1 consumidor real; **só** manter o broker se a PoC confirmar o consumidor externo |
| ADR-005 | MQTT + gateway | **Sim** | Mosquitto real + gateway paho; `UNIQUE(eventId)` no Core |
| ADR-006 | Pipelines por componente + métricas ↔ ASRs | **Sim** | Rodar Jenkins/Prometheus/Grafana reais; expor `/metrics` na IA e no gateway |

**Não adotado (e por quê):** microsserviço de Ranking (sem medição), Kafka (sem replay/vazão), segundo broker após MQTT (sem gatilho), serviço separado para RAG (sem métricas).

## Matriz de rastreabilidade (RF → RNF → ASR + RPC → alternativas → ADR → C4 → evidência)
| Desafio | RF | ASRs | RPC-chave | Decisão (ADR) | C4 | Evidência |
|---|---|---|---|---|---|---|
| D1 | RF01, RF02 | Manutenibilidade, Escalabilidade, Complexidade operacional | 6 devs, Spring, legado | Monólito Modular (001) | Container | Métricas antes/depois + gate |
| D2 | RF01, RF02 | Modificabilidade, Testabilidade | sem reescrita | Ports & Adapters no Ranking (002) | Component | Lab 7 PASS, 2 adapters |
| D3 | RF03, RF04 | Tolerância a falhas, Deploy indep., Escalabilidade | Python p/ IA, IA não bloqueia | Serviço Python (003) | Container | Matar o serviço: 6/6 fallback |
| D4 | RF02, RF05 | Tolerância a falhas, Recuperabilidade, Desacoplamento | essencial conclui sempre | Outbox + RabbitMQ (004) | Container + sequência | Sync 5/5 falhas × async 0/5 |
| D5 | RF06 | Conectividade intermitente, Eficiência, Interoperabilidade | baixo poder, rede instável | MQTT + gateway (005) | Container | 5 cenários PASS |
| D6 | RF01–RF06 | Observabilidade, Deploy indep., Recuperabilidade | Jenkins, Prom/Grafana | Pipelines por componente (006) | Deployment | Backlog 0→40→0, 0 perdas |

## C4 Container final (consolidado)
```mermaid
flowchart LR
  U[Usuário] --> FE[Front-end web] -->|REST| CORE
  DEV[Dispositivos IoT] -->|MQTT QoS1| MQTT[(Mosquitto)] --> GW[iot-gateway] -->|HTTP idempotente| CORE
  subgraph CORE["Core · Spring Boot · MONÓLITO MODULAR"]
    RK["ranking<br/>ports e adapters"]
    CS["curso · matricula · usuario"]
    RC["recomendacao<br/>breaker + fallback"]
    OB[outbox + relay]
  end
  CORE --> DB[(PostgreSQL)]
  RC -->|REST/JSON| IA["ia-service · FastAPI<br/>ML + RAG"]
  OB -->|AMQP| MQ[(RabbitMQ)] --> NOT[Notificação / Analytics]
  PROM[Prometheus · Grafana] -.scrape.-> CORE
  PROM -.scrape.-> IA
  PROM -.scrape.-> GW
```

## Verificação: o que foi executado e o que não foi
| Item | Status |
|---|---|
| Métricas de dependência (D1), gate de fronteira + violação injetada | ✅ executado |
| Domínio do Ranking + 2 adapters + troca de regra + medição 100 k (D2) | ✅ executado (JDK) |
| Falha do serviço Python, circuito, fallback (D3) | ✅ executado (stub com o contrato do FastAPI) |
| Síncrono × outbox, consumidor lento/fora, DLQ, idempotência (D4) | ✅ executado (broker e banco simulados) |
| MQTT: QoS1, duplicata, offline, payload inválido (D5) | ✅ executado (mini-broker MQTT 3.1.1 de laboratório) |
| Métrica, condição provocada, alerta (offline), gráfico (D6) | ✅ executado |
| `ci/gates.sh all` | ✅ executado |
| Compilação/testes do Core com Spring/JPA/Actuator (`mvn`) | ⚠️ **não executado** (sem Maven Central) — código novo revisado à mão |
| FastAPI `app.py`, gateway paho, Mosquitto, RabbitMQ, Docker Compose | ⚠️ **não executado** (sem pip/Docker); só sintaxe validada |
| Jenkinsfiles, Prometheus, Grafana | ⚠️ **não executado**; YAML/JSON validados sintaticamente |

**Primeira ação ao clonar:** `cd core && mvn -B verify` — é a confirmação pendente mais importante.
