#!/usr/bin/env bash
# Reexecuta o mini-lab do Desafio 2 (somente JDK 17+; sem Maven, sem banco).
set -e; cd "$(dirname "$0")"; OUT=$(mktemp -d)
S=../../core/src/main/java/com/exemplo/usuario/ranking
javac -encoding UTF-8 -d "$OUT" $S/domain/*.java $S/application/port/*.java $S/application/ConsultarRankingUseCase.java lab/RankingDomainLab.java
java -Dstdout.encoding=UTF-8 -cp "$OUT" RankingDomainLab
