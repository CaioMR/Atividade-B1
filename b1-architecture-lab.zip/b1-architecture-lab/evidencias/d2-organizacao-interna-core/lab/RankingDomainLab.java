import com.exemplo.usuario.ranking.application.ConsultarRankingUseCase;
import com.exemplo.usuario.ranking.application.port.PerfilGamificacaoReader;
import com.exemplo.usuario.ranking.domain.*;
import java.nio.file.*;
import java.util.*;

/** D2 - mini-lab: MESMA regra de domínio + MESMA suíte de contrato, rodando sobre 2 adapters diferentes
 *  (fake em memória e arquivo CSV). Nenhum Spring/JPA/banco no classpath. Sem JUnit: runner próprio (offline). */
public class RankingDomainLab {
    static int ok = 0, fail = 0;
    static void check(String nome, boolean cond) { if (cond) ok++; else fail++; System.out.println((cond ? "  PASS  " : "  FAIL  ") + nome); }

    /** Adapter 1: fake em memória (substitui o JPA nos testes de domínio). */
    static class InMemoryReader implements PerfilGamificacaoReader {
        final List<PerfilGamificacao> dados;
        InMemoryReader(List<PerfilGamificacao> d) { dados = d; }
        public List<PerfilGamificacao> listarTodos() { return dados; }
    }
    /** Adapter 2: lê CSV (id;nome;cursos;moedas) - prova que a fronteira aceita outra tecnologia de persistência. */
    static class CsvReader implements PerfilGamificacaoReader {
        final Path arq; CsvReader(Path a) { arq = a; }
        public List<PerfilGamificacao> listarTodos() {
            try { return Files.readAllLines(arq).stream().skip(1).map(l -> l.split(";"))
                .map(c -> new PerfilGamificacao(Long.valueOf(c[0]), c[1], Integer.parseInt(c[2]), Integer.parseInt(c[3]))).toList();
            } catch (Exception e) { throw new RuntimeException(e); }
        }
    }
    static List<PerfilGamificacao> massa() {
        return List.of(new PerfilGamificacao(1L, "Ana", 2, 50), new PerfilGamificacao(2L, "Bruno", 3, 0),
                       new PerfilGamificacao(3L, "Carla", 0, 400), new PerfilGamificacao(4L, "Abel", 2, 50));
    }
    public static void main(String[] a) throws Exception {
        // regra padrão: Carla=400, Bruno=300, Ana=250, Abel=250
        PontuacaoPolicy padrao = new PontuacaoPadrao();
        System.out.println("== Regra PADRÃO (AC1) ==");
        var fake = new InMemoryReader(massa());
        System.out.println("[fake em memória]");
        var rk = new ConsultarRankingUseCase(fake, padrao).executar();
        check("1o = Carla 400", rk.get(0).perfil().nome().equals("Carla") && rk.get(0).pontos() == 400);
        check("2o = Bruno 300", rk.get(1).perfil().nome().equals("Bruno") && rk.get(1).pontos() == 300);
        check("empate 250: Abel antes de Ana", rk.get(2).perfil().nome().equals("Abel") && rk.get(3).perfil().nome().equals("Ana"));
        check("posições 1..4 sequenciais", rk.stream().map(PosicaoRanking::posicao).toList().equals(List.of(1,2,3,4)));
        check("lista vazia -> ranking vazio", new ConsultarRankingUseCase(new InMemoryReader(List.of()), padrao).executar().isEmpty());

        Path csv = Files.createTempFile("perfis", ".csv");
        Files.writeString(csv, "id;nome;cursos;moedas\n1;Ana;2;50\n2;Bruno;3;0\n3;Carla;0;400\n4;Abel;2;50\n");
        System.out.println("[adapter CSV (outra persistência, mesma regra)]");
        var rk2 = new ConsultarRankingUseCase(new CsvReader(csv), padrao).executar();
        check("resultado idêntico ao do fake", rk2.equals(rk));

        System.out.println("== Mudança de regra (ASR modificabilidade): 150 pontos por curso (antes 100), sem tocar em adapter/banco ==");
        PontuacaoPolicy nova = p -> (long) p.cursosConcluidosComSucesso() * 150 + p.moedas();
        var rk3 = new ConsultarRankingUseCase(fake, nova).executar();
        check("nova regra: Bruno (450) passa Carla (400)", rk3.get(0).perfil().nome().equals("Bruno") && rk3.get(0).pontos() == 450);

        System.out.println("== Medição: ordenar em memória 100.000 perfis (premissa do cenário) ==");
        List<PerfilGamificacao> big = new ArrayList<>(); Random rnd = new Random(42);
        for (long i = 0; i < 100_000; i++) big.add(new PerfilGamificacao(i, "U" + i, rnd.nextInt(30), rnd.nextInt(5000)));
        var reader = new InMemoryReader(big);
        for (int w = 0; w < 5; w++) new ConsultarRankingUseCase(reader, padrao).executar(); // aquecimento JIT
        long[] t = new long[10];
        for (int i = 0; i < t.length; i++) { long s = System.nanoTime(); new ConsultarRankingUseCase(reader, padrao).executar(); t[i] = (System.nanoTime() - s) / 1_000_000; }
        Arrays.sort(t);
        System.out.println("  100k perfis, 10 execuções (ms, ordenado): " + Arrays.toString(t) + "  -> mediana " + t[5] + " ms");
        System.out.println("\nRESULTADO: " + ok + " PASS, " + fail + " FAIL");
        System.exit(fail == 0 ? 0 : 1);
    }
}
