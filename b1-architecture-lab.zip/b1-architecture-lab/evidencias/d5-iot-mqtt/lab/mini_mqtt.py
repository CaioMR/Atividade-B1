"""Mini broker/cliente MQTT 3.1.1 (stdlib) - SOMENTE para o laboratório offline (QoS 0/1, wildcards + e #, sem retain/LWT/sessão persistente).
Em produção/PoC usa-se Eclipse Mosquitto + paho-mqtt (ver ../stack). O protocolo de fio é o MQTT real."""
import socket, struct, threading, time

def enc_len(n):
    out = bytearray()
    while True:
        d = n % 128; n //= 128
        out.append(d | (128 if n else 0))
        if not n: return bytes(out)
def pstr(s): b = s.encode(); return struct.pack("!H", len(b)) + b
def packet(first, body): return bytes([first]) + enc_len(len(body)) + body

def read_packet(sock):
    h = sock.recv(1)
    if not h: raise ConnectionError("fechado")
    mult, n = 1, 0
    while True:
        b = sock.recv(1)[0]; n += (b & 127) * mult
        if not b & 128: break
        mult *= 128
    body = b""
    while len(body) < n:
        c = sock.recv(n - len(body))
        if not c: raise ConnectionError("fechado")
        body += c
    return h[0], body

def topic_match(flt, topic):
    f, t = flt.split("/"), topic.split("/")
    for i, p in enumerate(f):
        if p == "#": return True
        if i >= len(t) or (p != "+" and p != t[i]): return False
    return len(f) == len(t)

class Broker:
    def __init__(self, port):
        self.srv = socket.socket(); self.srv.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        self.srv.bind(("127.0.0.1", port)); self.srv.listen(); self.subs = []; self.lock = threading.Lock(); self.recebidas = 0
        threading.Thread(target=self._accept, daemon=True).start()
    def _accept(self):
        while True:
            try: c, _ = self.srv.accept()
            except OSError: return
            threading.Thread(target=self._serve, args=(c,), daemon=True).start()
    def _serve(self, c):
        pid = 0
        try:
            while True:
                first, body = read_packet(c); t = first >> 4
                if t == 1: c.sendall(packet(0x20, b"\x00\x00"))                       # CONNECT -> CONNACK
                elif t == 8:                                                          # SUBSCRIBE -> SUBACK
                    mid = struct.unpack("!H", body[:2])[0]; i = 2; granted = b""
                    while i < len(body):
                        l = struct.unpack("!H", body[i:i+2])[0]; flt = body[i+2:i+2+l].decode(); q = body[i+2+l]; i += 3 + l
                        with self.lock: self.subs.append((flt, min(q, 1), c)); granted += bytes([min(q, 1)])
                    c.sendall(packet(0x90, struct.pack("!H", mid) + granted))
                elif t == 3:                                                          # PUBLISH
                    qos = (first >> 1) & 3; l = struct.unpack("!H", body[:2])[0]; topic = body[2:2+l].decode(); i = 2 + l; mid = 0
                    if qos: mid = struct.unpack("!H", body[i:i+2])[0]; i += 2
                    payload = body[i:]; self.recebidas += 1
                    if qos: c.sendall(packet(0x40, struct.pack("!H", mid)))           # PUBACK ao publicador
                    with self.lock: alvos = [(q, s) for f, q, s in self.subs if topic_match(f, topic)]
                    for q, s in alvos:
                        q = min(q, qos); pid += 1
                        b = pstr(topic) + (struct.pack("!H", pid) if q else b"") + payload
                        try: s.sendall(packet(0x30 | (q << 1), b))
                        except OSError: pass
                elif t == 12: c.sendall(packet(0xD0, b""))                            # PINGREQ
                elif t == 14: return
        except Exception: pass
        finally:
            with self.lock: self.subs = [x for x in self.subs if x[2] is not c]
            c.close()
    def stop(self): self.srv.close()

class Client:
    def __init__(self, cid, port, on_message=None):
        self.cid, self.port, self.on_message, self.mid = cid, port, on_message, 0
        self.acks = {}; self.sock = None; self.drop_next_puback = False
    def connect(self):
        self.sock = socket.create_connection(("127.0.0.1", self.port))
        self.sock.sendall(packet(0x10, pstr("MQTT") + bytes([4, 2]) + struct.pack("!H", 60) + pstr(self.cid)))
        read_packet(self.sock); threading.Thread(target=self._loop, args=(self.sock,), daemon=True).start()
    def _loop(self, s):
        try:
            while True:
                first, body = read_packet(s); t = first >> 4
                if t == 3:
                    qos = (first >> 1) & 3; l = struct.unpack("!H", body[:2])[0]; topic = body[2:2+l].decode(); i = 2 + l
                    if qos: mid = struct.unpack("!H", body[i:i+2])[0]; i += 2; s.sendall(packet(0x40, struct.pack("!H", mid)))
                    if self.on_message: self.on_message(topic, body[i:])
                elif t in (4, 9):
                    mid = struct.unpack("!H", body[:2])[0]
                    if t == 4 and self.drop_next_puback: self.drop_next_puback = False; continue   # simula PUBACK perdido na rede
                    ev = self.acks.get(mid)
                    if ev: ev.set()
        except Exception: pass
    def subscribe(self, flt, qos=1):
        self.mid += 1; ev = self.acks[self.mid] = threading.Event()
        self.sock.sendall(packet(0x82, struct.pack("!H", self.mid) + pstr(flt) + bytes([qos]))); ev.wait(2)
    def publish(self, topic, payload, qos=1, timeout=0.5):
        """QoS1: retorna True se PUBACK recebido no prazo; False caso contrário (chamador decide reenviar)."""
        if not qos: self.sock.sendall(packet(0x30, pstr(topic) + payload)); return True
        self.mid += 1; mid = self.mid; ev = self.acks[mid] = threading.Event()
        self.sock.sendall(packet(0x32, pstr(topic) + struct.pack("!H", mid) + payload)); return ev.wait(timeout)
    def disconnect(self):
        try: self.sock.sendall(packet(0xE0, b""))
        except OSError: pass
        try: self.sock.close()
        except OSError: pass
