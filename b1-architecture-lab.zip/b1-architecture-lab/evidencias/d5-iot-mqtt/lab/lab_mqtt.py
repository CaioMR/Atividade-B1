#!/usr/bin/env python3
"""D5 - mini-lab: simulador IoT -> broker MQTT -> gateway/consumidor (transforma) -> Core (stub HTTP).
Cenários: (1) fluxo feliz; (2) PUBACK perdido -> reenvio -> gateway deduplica; (3) dispositivo OFFLINE -> store-and-forward ao reconectar;
(4) payload inválido -> descartado/registrado sem derrubar o gateway; (5) comparação de bytes MQTT x REST."""
import json, threading, time, uuid, sys
from http.server import BaseHTTPRequestHandler, HTTPServer
import urllib.request
from mini_mqtt import Broker, Client

PORT_B, PORT_CORE = 18830, 18081
core_recebidos = []

class CoreStub(BaseHTTPRequestHandler):                      # endpoint do Core (RF06): POST /api/iot/eventos
    def do_POST(self):
        n = int(self.headers["Content-Length"]); core_recebidos.append(json.loads(self.rfile.read(n)))
        self.send_response(202); self.end_headers()
    def log_message(self, *a): pass

# ---------------- gateway: assina MQTT, valida, deduplica, transforma e encaminha ao Core ----------------
vistos, descartados, duplicatas = set(), [], [0]
TIPOS = {"ini": "ATIVIDADE_INICIADA", "fim": "ATIVIDADE_CONCLUIDA", "pre": "PRESENCA_REGISTRADA"}
def gateway_on_message(topic, payload):
    try:
        e = json.loads(payload); lab = topic.split("/")[1]
        ev = {"eventId": e["id"], "tipo": TIPOS[e["e"]], "laboratorioId": lab, "dispositivoId": e["d"],
              "usuarioRef": e["u"], "atividadeId": e.get("a"), "ocorridoEm": e["t"]}
    except Exception as ex:
        descartados.append((topic, payload[:40], type(ex).__name__)); return
    if ev["eventId"] in vistos: duplicatas[0] += 1; return            # idempotência por eventId
    vistos.add(ev["eventId"])
    req = urllib.request.Request(f"http://127.0.0.1:{PORT_CORE}/api/iot/eventos", json.dumps(ev).encode(), {"Content-Type": "application/json"})
    urllib.request.urlopen(req, timeout=2).read()

def esperar(cond, t=3):
    f = time.time() + t
    while time.time() < f and not cond(): time.sleep(0.02)
    return cond()

def novo_evento(tipo, disp="dev-12", user="u-77", ativ="ativ-3"):
    return json.dumps({"e": tipo, "d": disp, "u": user, "a": ativ, "t": int(time.time()), "id": str(uuid.uuid4())}, separators=(",", ":")).encode()

class Dispositivo:
    """Simulador: publica QoS1; se não há PUBACK reenvia o MESMO eventId; offline -> bufferiza (store-and-forward)."""
    def __init__(self, cli, lab): self.cli, self.lab, self.buffer, self.online = cli, lab, [], True
    def emitir(self, tipo):
        p = novo_evento(tipo); topic = f"labs/{self.lab}/eventos/{tipo}"
        if not self.online: self.buffer.append((topic, p)); return "bufferizado"
        for tent in range(1, 4):
            if self.cli.publish(topic, p, 1, timeout=0.3): return f"ok (tentativa {tent})"
        self.buffer.append((topic, p)); return "falhou -> bufferizado"
    def ficar_offline(self): self.online = False; self.cli.disconnect()
    def reconectar(self):
        self.cli.connect(); self.online = True
        n = len(self.buffer)
        for topic, p in self.buffer: self.cli.publish(topic, p, 1)
        self.buffer.clear(); return n

if __name__ == "__main__":
    broker = Broker(PORT_B); core = HTTPServer(("127.0.0.1", PORT_CORE), CoreStub); threading.Thread(target=core.serve_forever, daemon=True).start()
    gw = Client("gateway-1", PORT_B, gateway_on_message); gw.connect(); gw.subscribe("labs/+/eventos/#", 1)
    dev_cli = Client("dev-12", PORT_B); dev_cli.connect(); dev = Dispositivo(dev_cli, "lab-A")
    falhas = []
    def chk(nome, cond): print(("  PASS  " if cond else "  FAIL  ") + nome); (None if cond else falhas.append(nome))

    print("CENÁRIO 1 - fluxo feliz (presença, início, conclusão)")
    for t in ("pre", "ini", "fim"): print("  dispositivo:", t, "->", dev.emitir(t))
    chk("Core recebeu 3 eventos transformados", esperar(lambda: len(core_recebidos) == 3))
    chk("tipos traduzidos para o vocabulário do Core", [e["tipo"] for e in core_recebidos] == ["PRESENCA_REGISTRADA", "ATIVIDADE_INICIADA", "ATIVIDADE_CONCLUIDA"])
    print("  exemplo ->", json.dumps(core_recebidos[2], ensure_ascii=False))

    print("\nCENÁRIO 2 - PUBACK perdido: dispositivo reenvia; gateway NÃO duplica")
    base = len(core_recebidos); dev_cli.drop_next_puback = True
    print("  dispositivo: fim ->", dev.emitir("fim"))
    time.sleep(0.4)
    chk("Core recebeu exatamente +1 evento", len(core_recebidos) == base + 1)
    chk("gateway suprimiu 1 duplicata", duplicatas[0] == 1)

    print("\nCENÁRIO 3 - dispositivo OFFLINE (Wi-Fi caiu) produz 3 eventos; reconecta")
    base = len(core_recebidos); dev.ficar_offline()
    for t in ("ini", "fim", "pre"): print("  offline:", t, "->", dev.emitir(t))
    chk("nenhum evento chegou ao Core enquanto offline", len(core_recebidos) == base)
    n = dev.reconectar(); print(f"  reconectou e descarregou {n} eventos bufferizados")
    chk("os 3 eventos chegaram ao Core após reconexão (sem perda)", esperar(lambda: len(core_recebidos) == base + 3))

    print("\nCENÁRIO 4 - payload inválido não derruba o gateway")
    base = len(core_recebidos); dev.cli.publish("labs/lab-A/eventos/fim", b"{lixo", 1); dev.cli.publish("labs/lab-A/eventos/fim", b'{"e":"xyz","id":"1","d":"a","u":"b","t":1}', 1)
    time.sleep(0.3)
    chk("2 payloads descartados e registrados", len(descartados) == 2)
    print("  descartados:", descartados)
    dev.emitir("fim"); chk("gateway continua processando após payload inválido", esperar(lambda: len(core_recebidos) == base + 1))

    print("\nCENÁRIO 5 - custo de bytes de um evento no fio MQTT (medido no pacote real)")
    from mini_mqtt import packet, pstr
    import struct
    p = novo_evento("fim"); pkt = packet(0x32, pstr("labs/lab-A/eventos/fim") + struct.pack("!H", 1) + p)
    print(f"  PUBLISH QoS1 = {len(pkt)} bytes (payload JSON compacto {len(p)} B) + PUBACK de 4 bytes; conexão TCP única e persistente.")
    print("  (REST exigiria linha de requisição + cabeçalhos HTTP + resposta a cada evento; não medido neste lab.)")
    print("\nRESULTADO:", "PASS" if not falhas else f"FAIL {falhas}")
    sys.exit(1 if falhas else 0)
