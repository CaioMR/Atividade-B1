"""Gateway MQTT->Core com paho-mqtt (stack alvo; não executado no ambiente de elaboração).
Mesma lógica validada no lab (../lab/lab_mqtt.py): valida, deduplica por eventId, traduz e faz POST ao Core."""
import json, os, requests
import paho.mqtt.client as mqtt

TIPOS = {"ini": "ATIVIDADE_INICIADA", "fim": "ATIVIDADE_CONCLUIDA", "pre": "PRESENCA_REGISTRADA"}
vistos = set()   # PoC: em memória. Produção: tabela com UNIQUE(eventId) no Core (idempotência durável).

def on_message(client, userdata, msg):
    try:
        e = json.loads(msg.payload); lab = msg.topic.split("/")[1]
        ev = {"eventId": e["id"], "tipo": TIPOS[e["e"]], "laboratorioId": lab, "dispositivoId": e["d"],
              "usuarioRef": e["u"], "atividadeId": e.get("a"), "ocorridoEm": e["t"]}
    except Exception:
        client.ack(msg.mid, msg.qos)   # payload inválido: confirma e descarta (registrar em iot_eventos_descartados_total)
        return
    if ev["eventId"] not in vistos:
        try:
            requests.post(os.environ["CORE_URL"], json=ev, timeout=2).raise_for_status()
            vistos.add(ev["eventId"])
        except Exception:
            return   # SEM ack: com sessão persistente o Mosquitto reentrega depois (Core fora não perde evento)
    client.ack(msg.mid, msg.qos)   # ack manual somente após o Core aceitar (ou duplicata já tratada)

c = mqtt.Client(mqtt.CallbackAPIVersion.VERSION2, client_id="gateway-1", clean_session=False, manual_ack=True)
c.username_pw_set("gateway", os.environ.get("MQTT_PASS", "troque-me"))
c.on_connect = lambda cl, u, f, rc, p=None: cl.subscribe("labs/+/eventos/#", qos=1)
c.on_message = on_message
c.connect(os.environ.get("MQTT_HOST", "localhost"), 1883, keepalive=30)
c.loop_forever()
