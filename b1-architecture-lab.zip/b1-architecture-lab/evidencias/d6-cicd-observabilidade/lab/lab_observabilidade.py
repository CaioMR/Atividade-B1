#!/usr/bin/env python3
"""D6 - mini-lab: gateway IoT (D5) instrumentado; o Core fica INDISPONÍVEL por ~4 s; um 'scraper' (papel do Prometheus) lê /metrics a cada 0,5 s.
Hipótese arquitetural testada (ASR confiabilidade/recuperabilidade do ADR-005): o backlog de retry sobe na falha, volta a zero na recuperação
e NENHUM evento é perdido. Saída: samples.csv, grafico-evidencia.png e veredito PASS/FAIL."""
import csv, json, os, sys, threading, time, urllib.request, uuid, collections
HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, HERE); sys.path.insert(0, os.path.join(HERE, "../../d5-iot-mqtt/lab"))
from http.server import BaseHTTPRequestHandler, HTTPServer
from mini_mqtt import Broker, Client
from metrics import Registry

PB, PC, PM = 18840, 18082, 18841
reg = Registry()
recebidos = reg.counter("iot_eventos_recebidos_total", "Eventos recebidos do broker MQTT")
duplicados = reg.counter("iot_eventos_duplicados_total", "Eventos descartados por idempotência")
falhas = reg.counter("iot_encaminhamento_falhas_total", "Falhas ao encaminhar ao Core")
encaminhados = reg.counter("iot_eventos_encaminhados_total", "Eventos entregues ao Core")
backlog = reg.gauge("iot_backlog_retry", "Eventos aguardando reenvio ao Core")
lat = reg.histogram("iot_encaminhamento_seconds", "Latência de encaminhamento ao Core")

core_recebidos, core_up = [], [True]
class Core(BaseHTTPRequestHandler):
    def do_POST(s):
        n = int(s.headers["Content-Length"]); body = json.loads(s.rfile.read(n))
        if not core_up[0]: s.send_response(503); s.end_headers(); return
        core_recebidos.append(body["eventId"]); s.send_response(202); s.end_headers()
    def log_message(s, *a): pass

fila_retry, vistos, lock = collections.deque(), set(), threading.Lock()
def enviar(ev):
    t = time.time()
    try:
        urllib.request.urlopen(urllib.request.Request(f"http://127.0.0.1:{PC}/", json.dumps(ev).encode(), {"Content-Type": "application/json"}), timeout=1).read()
        lat.observe(time.time() - t); encaminhados.inc(); return True
    except Exception: falhas.inc(); return False
def on_msg(topic, payload):
    ev = json.loads(payload); recebidos.inc()
    with lock:
        if ev["eventId"] in vistos: duplicados.inc(); return
        vistos.add(ev["eventId"])
    if not enviar(ev):
        with lock: fila_retry.append(ev); backlog.set(len(fila_retry))
def retry_loop():
    while True:
        time.sleep(0.3)
        with lock: pend = list(fila_retry)
        for ev in pend:
            if enviar(ev):
                with lock: fila_retry.remove(ev); backlog.set(len(fila_retry))
            else: break

if __name__ == "__main__":
    broker = Broker(PB); core = HTTPServer(("127.0.0.1", PC), Core); threading.Thread(target=core.serve_forever, daemon=True).start()
    reg.serve(PM); threading.Thread(target=retry_loop, daemon=True).start()
    gw = Client("gw", PB, on_msg); gw.connect(); gw.subscribe("labs/+/eventos/#", 1)
    dev = Client("dev", PB); dev.connect(); emitidos = []
    amostras = []; t0 = time.time(); fim = threading.Event()
    def scraper():
        while not fim.is_set():
            txt = urllib.request.urlopen(f"http://127.0.0.1:{PM}/metrics").read().decode()
            v = {l.split()[0]: float(l.split()[1]) for l in txt.splitlines() if l and not l.startswith("#") and "{" not in l.split()[0]}
            amostras.append((round(time.time() - t0, 2), v["iot_backlog_retry"], v["iot_encaminhamento_falhas_total"], v["iot_eventos_encaminhados_total"])); time.sleep(0.5)
    threading.Thread(target=scraper, daemon=True).start()
    def cenario():
        time.sleep(3); core_up[0] = False; print(f"[t={time.time()-t0:.1f}s] >>> Core INDISPONÍVEL (503)")
        time.sleep(4); core_up[0] = True; print(f"[t={time.time()-t0:.1f}s] >>> Core RECUPERADO")
    threading.Thread(target=cenario, daemon=True).start()
    while time.time() - t0 < 12:
        ev = {"id": str(uuid.uuid4()), "e": "fim", "d": "dev-1", "u": "u-1", "a": "a-1", "t": int(time.time())}
        emitidos.append(ev["id"])
        dev.publish("labs/lab-A/eventos/fim", json.dumps({"eventId": ev["id"], **ev}).encode(), 1); time.sleep(0.1)
    time.sleep(1.5); fim.set(); time.sleep(0.6)

    pico = max(a[1] for a in amostras); final = amostras[-1][1]
    janela = [a for a in amostras if a[1] > 0]; dur = (janela[-1][0] - janela[0][0]) if janela else 0
    perdidos = set(emitidos) - set(core_recebidos)
    print(f"\nemitidos={len(emitidos)} | entregues ao Core (únicos)={len(set(core_recebidos))} | perdidos={len(perdidos)} | duplicados no Core={len(core_recebidos)-len(set(core_recebidos))}")
    print(f"backlog: pico={pico:.0f}, final={final:.0f}, janela com backlog>0 ≈ {dur:.1f}s | falhas de encaminhamento={amostras[-1][2]:.0f}")
    # regra de alerta (equivalente a observabilidade/alerts.yml): iot_backlog_retry > 0 por >= 2s
    alerta = dur >= 2.0; print(f"alerta 'IotBacklogCrescendo' (backlog>0 por 2s) {'DISPARARIA' if alerta else 'não dispararia'} nesta janela")
    with open(os.path.join(HERE, "../samples.csv"), "w", newline="") as f:
        w = csv.writer(f); w.writerow(["t_s", "iot_backlog_retry", "iot_encaminhamento_falhas_total", "iot_eventos_encaminhados_total"]); w.writerows(amostras)
    open(os.path.join(HERE, "../metrics-final.txt"), "w").write(reg.render())
    import matplotlib; matplotlib.use("Agg"); import matplotlib.pyplot as plt
    fig, ax = plt.subplots(2, 1, figsize=(8, 5), sharex=True)
    t = [a[0] for a in amostras]
    ax[0].step(t, [a[1] for a in amostras], where="post", color="#1f77b4"); ax[0].set_ylabel("iot_backlog_retry"); ax[0].set_title("Evidência D6 - Core indisponível entre ~3s e ~7s (scrape a cada 0,5s)")
    ax[1].plot(t, [a[2] for a in amostras], label="falhas_total", color="#d62728"); ax[1].plot(t, [a[3] for a in amostras], label="encaminhados_total", color="#2ca02c")
    ax[1].legend(); ax[1].set_xlabel("segundos"); [x.axvspan(3, 7, color="grey", alpha=.15) for x in ax]
    plt.tight_layout(); plt.savefig(os.path.join(HERE, "../grafico-evidencia.png"), dpi=120)
    ok = not perdidos and final == 0 and pico > 0 and amostras[-1][2] > 0 and len(core_recebidos) == len(set(core_recebidos))
    print("RESULTADO:", "PASS" if ok else "FAIL"); sys.exit(0 if ok else 1)
