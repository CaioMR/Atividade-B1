"""Mini biblioteca de métricas no formato de exposição do Prometheus (stdlib). Em Spring usa-se Micrometer; em Python, prometheus_client."""
import threading, time
from http.server import BaseHTTPRequestHandler, HTTPServer

class Registry:
    def __init__(self): self.m = {}; self.l = threading.Lock()
    def counter(self, n, h): return self._add(n, h, "counter")
    def gauge(self, n, h): return self._add(n, h, "gauge")
    def histogram(self, n, h, buckets=(0.005, 0.01, 0.025, 0.05, 0.1, 0.25, 0.5, 1.0)):
        x = self._add(n, h, "histogram"); x.buckets = buckets; x.counts = [0] * len(buckets); x.sum = 0.0; x.n = 0; return x
    def _add(self, n, h, t):
        o = Metric(n, h, t, self.l); self.m[n] = o; return o
    def render(self):
        out = []
        with self.l:
            for o in self.m.values():
                out += [f"# HELP {o.name} {o.help}", f"# TYPE {o.name} {o.type}"]
                if o.type == "histogram":
                    cum = 0
                    for b, c in zip(o.buckets, o.counts): cum += c; out.append(f'{o.name}_bucket{{le="{b}"}} {cum}')
                    out += [f'{o.name}_bucket{{le="+Inf"}} {o.n}', f"{o.name}_sum {o.sum}", f"{o.name}_count {o.n}"]
                else: out.append(f"{o.name} {o.v}")
        return "\n".join(out) + "\n"
    def serve(self, port):
        reg = self
        class H(BaseHTTPRequestHandler):
            def do_GET(s):
                b = reg.render().encode(); s.send_response(200); s.send_header("Content-Type", "text/plain; version=0.0.4"); s.send_header("Content-Length", str(len(b))); s.end_headers(); s.wfile.write(b)
            def log_message(s, *a): pass
        srv = HTTPServer(("127.0.0.1", port), H); threading.Thread(target=srv.serve_forever, daemon=True).start(); return srv

class Metric:
    def __init__(self, n, h, t, lock): self.name, self.help, self.type, self.l, self.v = n, h, t, lock, 0
    def inc(self, d=1):
        with self.l: self.v += d
    def set(self, v):
        with self.l: self.v = v
    def observe(self, x):
        with self.l:
            self.sum += x; self.n += 1
            for i, b in enumerate(self.buckets):
                if x <= b: self.counts[i] += 1; break
