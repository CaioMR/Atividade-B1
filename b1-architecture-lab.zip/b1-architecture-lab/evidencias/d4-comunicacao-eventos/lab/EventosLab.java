import java.util.*;
import java.util.function.Supplier;

/** D4 - mini-lab: "concluir curso" com notificação SÍNCRONA (REST) x ASSÍNCRONA (transactional outbox + broker durável).
 *  Cenários: (1) consumidor lento; (2) consumidor INDISPONÍVEL; (3) recuperação com duplicidade e mensagem-veneno.
 *  O banco e o broker são simulados em memória, mas a LÓGICA é a decidida no ADR-004: commit atômico matrícula+recompensa+outbox,
 *  relay at-least-once, consumidor idempotente, DLQ. Somente JDK. */
public class EventosLab {
    // ---------- "banco" com transação por snapshot/rollback ----------
    static class Db {
        Map<Integer, String> matricula = new TreeMap<>(); Map<Integer, Integer> moedas = new TreeMap<>();
        List<Event> outbox = new ArrayList<>();
        <T> T tx(Supplier<T> body) {
            var m = new TreeMap<>(matricula); var c = new TreeMap<>(moedas); var o = new ArrayList<>(outbox);
            try { return body.get(); } catch (RuntimeException e) { matricula = m; moedas = c; outbox = o; throw e; }
        }
    }
    record Event(String id, String tipo, int matriculaId) {}
    static class Outbox { Event e; boolean enviado; Outbox(Event e) { this.e = e; } }

    // ---------- consumidor externo (Notificação) ----------
    static class Notificacao {
        volatile boolean up = true; volatile long latenciaMs = 0;
        List<String> enviadas = new ArrayList<>(); Set<String> vistos = new HashSet<>();
        void enviarSync(int matriculaId) { // chamada REST do Core
            if (!up) throw new RuntimeException("notificação indisponível (connection refused)");
            sleep(latenciaMs); enviadas.add("m" + matriculaId);
        }
        void consumir(Event e) { // consumidor de fila: idempotente
            if (e.tipo().equals("VENENO")) throw new IllegalStateException("payload inválido");
            if (!vistos.add(e.id())) return;           // idempotência por eventId
            enviadas.add("m" + e.matriculaId());
        }
    }
    static void sleep(long ms) { try { Thread.sleep(ms); } catch (InterruptedException ignored) {} }

    // ---------- fluxos ----------
    static void concluirSync(Db db, Notificacao n, int id) {
        db.tx(() -> { db.matricula.put(id, "CONCLUIDA"); db.moedas.merge(1, 100, Integer::sum); n.enviarSync(id); return null; });
    }
    static void concluirAsync(Db db, int id) {
        db.tx(() -> { db.matricula.put(id, "CONCLUIDA"); db.moedas.merge(1, 100, Integer::sum);
            db.outbox.add(new Event(UUID.randomUUID().toString(), "CURSO_CONCLUIDO", id)); return null; });
    }

    // ---------- relay outbox -> broker durável; consumidor com retry/DLQ ----------
    static class Broker {
        Deque<Event> fila = new ArrayDeque<>(); List<Event> dlq = new ArrayList<>(); Map<String, Integer> tentativas = new HashMap<>();
        void publicar(Event e) { fila.add(e); }
        void drenar(Notificacao n) {
            if (!n.up) return; // consumidor fora: mensagens permanecem duráveis na fila
            while (!fila.isEmpty()) { Event e = fila.poll();
                try { n.consumir(e); } catch (RuntimeException ex) {
                    int t = tentativas.merge(e.id(), 1, Integer::sum);
                    if (t >= 3) dlq.add(e); else fila.add(e);
                } }
        }
    }
    static int relay(Db db, Broker b) { // at-least-once: marca enviado só após publicar; aqui publica todos os pendentes
        int n = db.outbox.size(); for (Event e : db.outbox) b.publicar(e); db.outbox.clear(); return n;
    }

    static double media(long[] a) { return Arrays.stream(a).average().orElse(0); }
    public static void main(String[] args) {
        Notificacao n = new Notificacao();
        System.out.println("== CENÁRIO 1: consumidor LENTO (300 ms por notificação), 10 conclusões ==");
        n.latenciaMs = 300; long[] s = new long[10], a = new long[10]; Db d1 = new Db(), d2 = new Db();
        for (int i = 0; i < 10; i++) { long t = System.nanoTime(); concluirSync(d1, n, i); s[i] = (System.nanoTime() - t) / 1_000_000; }
        for (int i = 0; i < 10; i++) { long t = System.nanoTime(); concluirAsync(d2, i); a[i] = (System.nanoTime() - t) / 1_000_000; }
        System.out.printf("  SYNC : latência média da conclusão = %.0f ms%n  ASYNC: latência média da conclusão = %.0f ms%n", media(s), media(a));

        System.out.println("\n== CENÁRIO 2: consumidor INDISPONÍVEL, 5 conclusões ==");
        Notificacao off = new Notificacao(); off.up = false; Db ds = new Db(), da = new Db(); int falhasSync = 0;
        for (int i = 1; i <= 5; i++) { try { concluirSync(ds, off, i); } catch (RuntimeException e) { falhasSync++; } }
        for (int i = 1; i <= 5; i++) concluirAsync(da, i);
        System.out.println("  SYNC : conclusões que FALHARAM = " + falhasSync + "/5 | matrículas concluídas no banco = " + ds.matricula.size() + " | moedas creditadas = " + ds.moedas.getOrDefault(1, 0));
        System.out.println("  ASYNC: conclusões que FALHARAM = 0/5 | matrículas concluídas no banco = " + da.matricula.size() + " | moedas creditadas = " + da.moedas.getOrDefault(1, 0) + " | eventos pendentes no outbox = " + da.outbox.size());

        System.out.println("\n== CENÁRIO 3: recuperação ==");
        Broker br = new Broker(); int pub = relay(da, br);
        System.out.println("  relay publicou " + pub + " eventos no broker (consumidor ainda fora): fila=" + br.fila.size() + ", notificações enviadas=" + off.enviadas.size());
        Event dup = br.fila.peek(); br.publicar(dup);                              // redelivery (at-least-once)
        br.publicar(new Event(UUID.randomUUID().toString(), "VENENO", -1));         // mensagem-veneno
        off.up = true; br.drenar(off);                                              // consumidor volta
        System.out.println("  consumidor VOLTOU: notificações enviadas = " + off.enviadas.size() + " (esperado 5; duplicata suprimida pela idempotência)");
        System.out.println("  fila = " + br.fila.size() + " | DLQ = " + br.dlq.size() + " (mensagem-veneno isolada após 3 tentativas)");
        boolean ok = falhasSync == 5 && ds.matricula.isEmpty() && da.matricula.size() == 5 && off.enviadas.size() == 5 && br.dlq.size() == 1 && br.fila.isEmpty();
        System.out.println("\nRESULTADO: " + (ok ? "PASS" : "FAIL") + " - assert: sync perde 5/5 conclusões; async preserva 5/5 e entrega 5/5 sem duplicar");
        System.exit(ok ? 0 : 1);
    }
}
