#!/usr/bin/env python3
"""Stub stdlib com o MESMO contrato HTTP do ia-service/app.py (ambiente de elaboração não tem fastapi).
Uso: python3 ia_stub.py <porta>"""
import json, sys
from http.server import BaseHTTPRequestHandler, HTTPServer

class H(BaseHTTPRequestHandler):
    def _send(self, code, obj):
        b = json.dumps(obj).encode(); self.send_response(code)
        self.send_header("Content-Type", "application/json"); self.send_header("Content-Length", str(len(b)))
        self.end_headers(); self.wfile.write(b)
    def do_GET(self):
        if self.path == "/health": return self._send(200, {"status": "UP"})
        if self.path.startswith("/v1/recomendacoes/"):
            uid = int(self.path.split("/")[3].split("?")[0])
            itens = [{"cursoId": i, "titulo": f"Curso recomendado {i}", "score": round(1 / (1 + (i + uid) % 7), 3)} for i in range(1, 4)]
            return self._send(200, {"usuarioId": uid, "origem": "ia-ml", "itens": itens})
        self._send(404, {"erro": "nao encontrado"})
    def do_POST(self):
        if self.path == "/v1/assistente/perguntar":
            n = int(self.headers.get("Content-Length", 0)); p = json.loads(self.rfile.read(n))
            return self._send(200, {"usuarioId": p["usuarioId"], "origem": "ia-rag", "resposta": f"[resposta gerada para: {p['texto']}]"})
        self._send(404, {"erro": "nao encontrado"})
    def log_message(self, *a): pass

if __name__ == "__main__":
    HTTPServer(("127.0.0.1", int(sys.argv[1])), H).serve_forever()
