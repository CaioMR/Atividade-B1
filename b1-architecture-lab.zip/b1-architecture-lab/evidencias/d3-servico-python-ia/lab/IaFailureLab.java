import java.net.URI;
import java.net.http.*;
import java.time.Duration;
import java.util.*;

/** D3 - mini-lab: cliente do Core (timeout + circuit breaker + fallback) consumindo o serviço Python.
 *  Fase 1: IA no ar. Fase 2: processo Python é MORTO -> Core degrada sem falhar. Fase 3: IA volta -> circuito fecha.
 *  Mesma política que core/.../recomendacao/internal/IaHttpClient.java (Spring RestClient). Somente JDK. */
public class IaFailureLab {
    static final HttpClient http = HttpClient.newBuilder().connectTimeout(Duration.ofMillis(300)).build();
    static int falhasSeguidas = 0; static long abertoAte = 0;
    static final int LIMITE = 3; static final long ABERTO_MS = 2000;

    record Resultado(String origem, String corpo, long ms) {}

    /** Fluxo ESSENCIAL (nunca depende da IA). */
    static String concluirCurso(long matriculaId) { return "matricula " + matriculaId + " CONCLUIDA (+100 pts, +moedas) - persistida no Core"; }

    static Resultado recomendar(long usuarioId) {
        long t0 = System.nanoTime();
        if (System.currentTimeMillis() < abertoAte) return new Resultado("FALLBACK(circuito ABERTO, sem chamada de rede)", fallback(usuarioId), (System.nanoTime() - t0) / 1_000_000);
        try {
            var req = HttpRequest.newBuilder(URI.create("http://127.0.0.1:" + PORTA + "/v1/recomendacoes/" + usuarioId)).timeout(Duration.ofMillis(800)).GET().build();
            var resp = http.send(req, HttpResponse.BodyHandlers.ofString());
            if (resp.statusCode() != 200) throw new RuntimeException("HTTP " + resp.statusCode());
            falhasSeguidas = 0; return new Resultado("IA (ia-ml)", resp.body(), (System.nanoTime() - t0) / 1_000_000);
        } catch (Exception e) {
            if (++falhasSeguidas >= LIMITE) { abertoAte = System.currentTimeMillis() + ABERTO_MS; }
            return new Resultado("FALLBACK(" + e.getClass().getSimpleName() + ", falhas=" + falhasSeguidas + ")", fallback(usuarioId), (System.nanoTime() - t0) / 1_000_000);
        }
    }
    /** Comportamento degradado aceito: cursos mais concluídos (dado do próprio Core), marcado como não personalizado. */
    static String fallback(long uid) { return "{\"usuarioId\":" + uid + ",\"origem\":\"core-fallback\",\"personalizado\":false,\"itens\":[\"Curso mais concluído 1\",\"Curso mais concluído 2\"]}"; }

    static int PORTA = 18083; static Process py;
    static void subir() throws Exception {
        py = new ProcessBuilder("python3", "-I", "ia_stub.py", String.valueOf(PORTA)).inheritIO().start();
        for (int i = 0; i < 50; i++) { try { Thread.sleep(100);
            if (http.send(HttpRequest.newBuilder(URI.create("http://127.0.0.1:" + PORTA + "/health")).build(), HttpResponse.BodyHandlers.ofString()).statusCode() == 200) return; } catch (Exception ignore) {} }
        throw new RuntimeException("stub não subiu");
    }
    static void p(String fase, Resultado r) { System.out.printf("  [%s] origem=%s | %d ms | %s%n", fase, r.origem(), r.ms(), r.corpo().length() > 90 ? r.corpo().substring(0, 90) + "..." : r.corpo()); }

    public static void main(String[] a) throws Exception {
        subir();
        System.out.println("FASE 1 - serviço Python NO AR");
        p("rec", recomendar(7));
        var resp = http.send(HttpRequest.newBuilder(URI.create("http://127.0.0.1:" + PORTA + "/v1/assistente/perguntar")).header("Content-Type", "application/json")
            .POST(HttpRequest.BodyPublishers.ofString("{\"usuarioId\":7,\"texto\":\"O que é JPA?\"}")).build(), HttpResponse.BodyHandlers.ofString());
        System.out.println("  [rag] " + resp.body());
        System.out.println("  [core] " + concluirCurso(1));

        System.out.println("\nFASE 2 - processo Python MORTO (kill -9 simulado via destroyForcibly)");
        py.destroyForcibly().waitFor();
        boolean essencialOk = true; int fallbacks = 0;
        for (int i = 1; i <= 6; i++) {
            Resultado r = recomendar(7); p("rec #" + i, r); if (r.origem().startsWith("FALLBACK")) fallbacks++;
            try { System.out.println("  [core] " + concluirCurso(100 + i)); } catch (Exception e) { essencialOk = false; }
        }
        System.out.println("  -> fallbacks: " + fallbacks + "/6 | fluxo essencial (concluir curso) OK em todas: " + essencialOk);

        System.out.println("\nFASE 3 - serviço volta; circuito fecha após o tempo de espera (" + ABERTO_MS + " ms)");
        subir(); Thread.sleep(ABERTO_MS + 100);
        p("rec", recomendar(7));
        py.destroyForcibly().waitFor();
        System.out.println("\nCONCLUSÃO: queda do serviço Python não bloqueou o fluxo essencial; recomendação degradou para fallback e o custo caiu de timeout/conexão recusada para ~0 ms com o circuito aberto.");
    }
}
