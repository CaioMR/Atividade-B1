"""Serviço de IA (Python/FastAPI). Fronteira única Core<->IA, com DUAS capacidades isoladas por router:
 - /v1/recomendacoes  (ML: leve, cacheável, latência de ms)
 - /v1/assistente     (RAG/LLM: lento, caro, carga em rajadas)
Hoje um deployable; os routers não compartilham código, então podem virar 2 serviços se as métricas pedirem (ADR-003).
NÃO executado no ambiente de elaboração (sem fastapi/pip). O contrato idêntico foi exercitado por lab/ia_stub.py."""
from fastapi import APIRouter, FastAPI
from pydantic import BaseModel

app = FastAPI(title="ia-service", version="1.0.0")
ml = APIRouter(prefix="/v1/recomendacoes", tags=["ML"])
rag = APIRouter(prefix="/v1/assistente", tags=["RAG"])

class Pergunta(BaseModel):
    usuarioId: int
    texto: str

@app.get("/health")
def health():
    return {"status": "UP"}

@ml.get("/{usuario_id}")
def recomendar(usuario_id: int, limite: int = 3):
    # Placeholder do modelo: troque por model.predict(...). O contrato HTTP é o que a decisão fixa.
    catalogo = [{"cursoId": i, "titulo": f"Curso recomendado {i}", "score": round(1 / (1 + (i + usuario_id) % 7), 3)} for i in range(1, 8)]
    return {"usuarioId": usuario_id, "origem": "ia-ml", "itens": sorted(catalogo, key=lambda x: -x["score"])[:limite]}

@rag.post("/perguntar")
def perguntar(p: Pergunta):
    # Placeholder do pipeline RAG: recuperar trechos (vector DB) + gerar resposta (LLM).
    return {"usuarioId": p.usuarioId, "origem": "ia-rag", "resposta": f"[resposta gerada para: {p.texto}]"}

app.include_router(ml)
app.include_router(rag)
