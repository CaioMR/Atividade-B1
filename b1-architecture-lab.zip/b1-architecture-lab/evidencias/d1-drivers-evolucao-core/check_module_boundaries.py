#!/usr/bin/env python3
"""Gate de fronteira modular (D1 -> usado no CI do D6).
Falha se um módulo importar pacote '.internal.' de OUTRO módulo, exceto os vazamentos já conhecidos (baseline).
O baseline só pode DIMINUIR (catraca): corrigir um vazamento = remover a linha de baseline-vazamentos.txt."""
import re, sys, pathlib
root = pathlib.Path(sys.argv[1]); base = pathlib.Path(sys.argv[2])
known = {l.strip() for l in base.read_text().splitlines() if l.strip() and not l.startswith("#")}
found = set()
for f in root.rglob("*.java"):
    t = f.read_text(encoding="utf-8")
    pkg = re.search(r"^package\s+com\.exemplo\.usuario\.(\w+)", t, re.M)
    if not pkg: continue
    me = pkg.group(1)
    for imp in re.findall(r"^import\s+com\.exemplo\.usuario\.(\w+)\.internal\.[\w.]*?(\w+);", t, re.M):
        if imp[0] != me: found.add(f"{f.stem} ({me}) -> {imp[0]}.internal.{imp[1]}")
new, fixed = sorted(found - known), sorted(known - found)
print(f"vazamentos encontrados: {len(found)} | no baseline: {len(known)}")
for n in new: print("  NOVO (bloqueia o build):", n)
for x in fixed: print("  CORRIGIDO - remova do baseline:", x)
sys.exit(1 if new else 0)
