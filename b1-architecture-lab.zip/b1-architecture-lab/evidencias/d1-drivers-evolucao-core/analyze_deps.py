#!/usr/bin/env python3
"""D1 - compara acoplamento estrutural: Monólito em Camadas (antes) x Modular (depois).
Uso: python3 analyze_deps.py <dir_java_camadas> <dir_java_modular>
Heurística: o 'módulo' de cada classe é a capacidade de negócio (ranking, curso, matricula, usuario).
Camadas: capacidade inferida pelo nome da classe. Modular: pelo pacote. Apenas stdlib."""
import re, sys, pathlib, json
CAPS = ["ranking", "matricula", "curso", "usuario"]
USUARIO_NAMES = ("Usuario", "Assinatura", "PlanoAssinatura", "EmailUsuario", "NomeUsuario", "SenhaCriptografada")
SHARED = ("Application", "Config", "ApiExceptionHandler", "HomeController", "ApiException")

def cap_by_name(cls):
    if cls.startswith("Ranking"): return "ranking"
    if cls.startswith(("Matricula", "ConcluirMatricula", "StatusMatricula")): return "matricula"
    if cls.startswith(("Curso", "TituloCurso", "DescricaoCurso")): return "curso"
    if cls.startswith(USUARIO_NAMES): return "usuario"
    return "shared"

def scan(root, modular):
    root = pathlib.Path(root); classes = {}
    for f in root.rglob("*.java"):
        if f.name == "package-info.java": continue
        txt = f.read_text(encoding="utf-8")
        pkg = re.search(r"^package\s+([\w.]+);", txt, re.M).group(1)
        cls = f.stem
        if modular:
            parts = pkg.split(".")
            cap = parts[3] if len(parts) > 3 else "shared"
            cap = cap if cap in CAPS else "shared"
        else:
            cap = cap_by_name(cls)
        classes[cls] = dict(cap=cap, pkg=pkg, txt=txt, internal=".internal." in pkg + ".")
    edges = []
    for cls, c in classes.items():
        for imp in re.findall(r"^import\s+com\.exemplo\.usuario\.([\w.]+);", c["txt"], re.M):
            tgt = imp.split(".")[-1]
            if tgt in classes:
                edges.append((cls, c["cap"], tgt, classes[tgt]["cap"], classes[tgt]["internal"]))
    return classes, edges

def report(label, classes, edges):
    cross = [e for e in edges if e[1] != e[3] and "shared" not in (e[1], e[3])]
    internal_leaks = [e for e in cross if e[4]]
    pairs = sorted({(e[1], e[3]) for e in cross})
    spread = {}
    for cap in CAPS:
        pk = {c["pkg"] for c in classes.values() if c["cap"] == cap}
        spread[cap] = len(pk)
    return dict(label=label, classes=len(classes), edges=len(edges), cross_module=len(cross),
                cross_into_internal=len(internal_leaks), pairs=[f"{a}->{b}" for a, b in pairs],
                packages_per_capability=spread,
                leaks=[f"{e[0]}({e[1]}) -> {e[2]}({e[3]})" for e in internal_leaks],
                cross_detail=[f"{e[0]}({e[1]}) -> {e[2]}({e[3]})" for e in cross])

if __name__ == "__main__":
    a = report("ANTES: camadas", *scan(sys.argv[1], False))
    d = report("DEPOIS: modular", *scan(sys.argv[2], True))
    print(json.dumps([a, d], indent=2, ensure_ascii=False))
